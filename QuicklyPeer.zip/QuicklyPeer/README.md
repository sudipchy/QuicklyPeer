# QuicklyPeer — All-in-One Package

Peer-to-peer file transfer between **browsers** and **Android apps** using WebRTC.
Send → a **Transfer ID** is shown → the receiver enters it → sender **approves** →
receiver **accepts** → files stream P2P → received files are **saved automatically to disk**.

```
QuicklyPeer/
├── web-app/          Next.js web app (browser side) — full source
└── flutter-app/      Flutter Android app — full source
```

Works for **all four combinations**: browser → app, app → browser, browser ↔ browser, app ↔ app.
Works on the **same WiFi** (direct LAN-speed P2P) and **across different WiFi / internet**
(WebRTC + Google STUN, best effort on restrictive networks).

**Technology:** WebRTC DataChannel for the file data (P2P, no file ever touches the
server) + Socket.IO signaling server (control messages only: pairing, approve, WebRTC
handshake) + a small REST API for sessions.

---

## 1. Run the web app (browser side)

Requirements: Node.js 18+ (or Bun).

```bash
cd web-app
npm install          # or: bun install
npx prisma db push   # creates the SQLite session database
npm run dev          # starts web app on http://localhost:3000
```

Start the signaling server (second terminal):

```bash
cd web-app/mini-services/signaling-server
npm install          # or: bun install
npx tsx index.ts     # Socket.IO server on http://localhost:3003 (path '/')
```

Then configure the gateway so the browser reaches both from one origin.
`web-app/Caddyfile` contains the exact gateway config used in this project:

- Web app on `:3000`
- Signaling proxied at `http://localhost:81/?XTransformPort=3003`

If you deploy behind your own reverse proxy instead, proxy everything to
`:3000` and make `/socket.io/` (path `/` in this build) go to `:3003`.
On the same machine without any proxy, the web app falls back to
`http://localhost:3003` automatically.

## 2. Build the Android app (Flutter side)

Requirements: Flutter SDK 3.24+ and Android SDK (`flutter doctor` to verify).

```bash
cd flutter-app
flutter create --project-name quickly_peer --org com.quicklypeer .
flutter run                    # device/emulator connected
flutter build apk --release    # build/app/outputs/flutter-apk/app-release.apk
```

One-time manifest edit (`android/app/src/main/AndroidManifest.xml`):

```xml
<uses-permission android:name="android.permission.INTERNET"/>
```

and inside `<application ...>` (only needed for `http://` server URLs):

```xml
android:usesCleartextTraffic="true"
```

## 3. Connect devices

1. Open the web app URL in any browser.
2. In the Flutter app's home screen, paste **the same base URL** into
   *Server URL* (remembered across launches).
3. **Sender** picks files → gets a big **Transfer ID**.
4. **Receiver** enters the Transfer ID → sender approves → receiver accepts →
   files stream → auto-saved:
   - browser: standard Downloads folder
   - Android: `Android/data/com.quicklypeer.quickly_peer/files/Download`
     (plus a Share button on the done screen)

## 4. Where each piece lives

| Piece | Path |
|---|---|
| Web UI + transfer logic | `web-app/src/app/page.tsx`, `web-app/src/lib/*` |
| REST session API | `web-app/src/app/api/sessions/*` |
| Signaling server | `web-app/mini-services/signaling-server/index.ts` |
| Flutter engine (WebRTC + wire protocol) | `flutter-app/lib/transfer_engine.dart` |
| Flutter signaling client | `flutter-app/lib/signaling.dart` |
| Flutter screens | `flutter-app/lib/screens.dart` |

Both sides implement the exact same wire protocol, so any sender can talk to
any receiver regardless of platform.

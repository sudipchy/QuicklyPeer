# QuicklyPeer for Android

Flutter companion app for the **QuicklyPeer** web app. Transfer files
peer-to-peer (browser ↔ app, app ↔ browser, app ↔ app) over WebRTC — on the
**same WiFi** (direct, LAN speed) or across the **internet** (P2P via STUN).

## How pairing works

1. **Sender** picks files and gets a **Transfer ID** (shown big on screen).
2. **Receiver** enters that Transfer ID to connect.
3. **Sender approves** the incoming connection request.
4. **Receiver taps Accept** for the incoming files — sending starts only then.
5. Received files are **saved automatically** to the app's Downloads folder
   (`Android/data/com.quicklypeer.quickly_peer/files/Download`) — open the
   Share (⤴) button on the done screen to move/share them anywhere.

## Prerequisites

- [Flutter SDK](https://docs.flutter.dev/get-started/install) 3.24 or newer
- Android SDK (installed with Flutter) — run `flutter doctor` to confirm

## Setup (generates the android/ folder)

```bash
cd quicklypeer-flutter
flutter create --project-name quickly_peer --org com.quicklypeer .
```

Then open `android/app/src/main/AndroidManifest.xml` and:

1. Add the INTERNET permission inside `<manifest>` (before `<application>`):

```xml
<uses-permission android:name="android.permission.INTERNET"/>
```

2. Add cleartext support inside the `<application ...>` tag (only needed if
   your server URL starts with `http://` instead of `https://`):

```xml
android:usesCleartextTraffic="true"
```

## Run / Build

```bash
flutter run                       # run on a connected device/emulator
flutter build apk --release       # APK at build/app/outputs/flutter-apk/app-release.apk
```

## Connecting to the web app

1. Open the QuicklyPeer **web app** URL in your browser (e.g.
   `https://preview-xxxx.space-z.ai`).
2. On the phone app's home screen, paste **the same URL** into the
   *Server URL* field (it is remembered).
3. All devices must use the **same server URL**.

| Direction | Same WiFi | Different WiFi |
|---|---|---|
| Browser → App | ✅ direct | ✅ P2P via STUN |
| App → Browser | ✅ direct | ✅ P2P via STUN |
| App → App | ✅ direct | ✅ P2P via STUN |

> On very restrictive corporate networks, P2P across the internet may fail —
> same-WiFi transfers always work.

## Troubleshooting

- **Gradle errors after `flutter create`** — delete the `android/` folder and
  re-run the `flutter create --project-name quickly_peer --org com.quicklypeer .`
  command with your Flutter version.
- **Connection hangs** — open the server URL in the phone's browser to confirm
  it is reachable; check that both sides use the exact same URL.
- **"Sender is not online"** — keep the sender's tab/app open while the
  receiver joins.
- **Where are my files?** — app-specific storage:
  `Android/data/com.quicklypeer.quickly_peer/files/Download` (visible with any
  file manager; use the Share button to export elsewhere).

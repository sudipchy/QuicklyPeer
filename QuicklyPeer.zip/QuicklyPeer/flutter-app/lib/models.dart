import 'utils.dart';

/// Device description sent to the REST API and the signaling server.
class DeviceInfo {
  final String deviceType;
  final String browser;
  final String os;
  final String userAgent;

  const DeviceInfo({
    this.deviceType = 'mobile',
    this.browser = 'Flutter',
    this.os = 'Android',
    this.userAgent = 'quicklypeer-flutter/1.0',
  });

  Map<String, dynamic> toJson() => {
        'deviceType': deviceType,
        'browser': browser,
        'os': os,
        'userAgent': userAgent,
      };
}

/// Metadata of one file in the transfer (matches the web wire protocol).
class FileMeta {
  final String id;
  final String filename;
  final int filesize;
  final String mimeType;

  FileMeta({
    required this.id,
    required this.filename,
    required this.filesize,
    required this.mimeType,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'filename': filename,
        'filesize': filesize,
        'mimeType': mimeType,
      };

  factory FileMeta.fromJson(Map<String, dynamic> j) => FileMeta(
        id: j['id']?.toString() ?? randomHex(8),
        filename: j['filename']?.toString() ?? 'file',
        filesize: (j['filesize'] as num?)?.toInt() ?? 0,
        mimeType: j['mimeType']?.toString() ?? 'application/octet-stream',
      );
}

/// Per-file progress shown in the UI (sender + receiver).
class FileProgress {
  final FileMeta meta;
  final String? localPath; // sender only
  int received;
  String status; // pending | transferring | done | error
  String? savedPath; // receiver only

  FileProgress({
    required this.meta,
    this.localPath,
    this.received = 0,
    this.status = 'pending',
    this.savedPath,
  });

  double get ratio => meta.filesize <= 0
      ? (status == 'done' ? 1.0 : 0.0)
      : (received / meta.filesize).clamp(0.0, 1.0);
}

/// High-level UI state machine (mirrors the web app views).
enum Phase {
  idle,
  senderWaiting,
  senderIncoming,
  senderConnected,
  senderRequesting,
  receiverJoining,
  receiverWaiting,
  receiverConnected,
  receiverConfirm,
  transferring,
  done,
  error,
}

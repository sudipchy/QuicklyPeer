import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

/// REST client for the QuicklyPeer session API.
class RestApi {
  final String base;
  RestApi(this.base);

  Uri _u(String path) => Uri.parse('$base$path');

  Map<String, dynamic> _json(http.Response res) {
    Map<String, dynamic> body = {};
    try {
      final decoded = jsonDecode(res.body.isEmpty ? '{}' : res.body);
      if (decoded is Map<String, dynamic>) body = decoded;
    } catch (_) {
      // Non-JSON body — fall through with an empty map.
    }
    if (res.statusCode >= 400) {
      throw Exception(
          (body['error'] ?? 'Request failed (${res.statusCode})').toString());
    }
    return body;
  }

  /// POST /api/sessions — create a transfer session (sender).
  Future<Map<String, dynamic>> createSession(Map<String, dynamic> device) async {
    final res = await http
        .post(
          _u('/api/sessions'),
          headers: {'content-type': 'application/json'},
          body: jsonEncode({'senderDevice': device}),
        )
        .timeout(const Duration(seconds: 20));
    return _json(res);
  }

  /// POST /api/sessions/{id}/files — register the file manifest (sender).
  Future<Map<String, dynamic>> registerFiles(
      String transferId, String token, List<Map<String, dynamic>> files) async {
    final res = await http
        .post(
          _u('/api/sessions/$transferId/files'),
          headers: {
            'content-type': 'application/json',
            'x-session-token': token,
          },
          body: jsonEncode({'files': files}),
        )
        .timeout(const Duration(seconds: 20));
    return _json(res);
  }

  /// POST /api/sessions/{id}/join — receiver joins by Transfer ID.
  Future<Map<String, dynamic>> joinSession(
      String transferId, Map<String, dynamic> device) async {
    final res = await http
        .post(
          _u('/api/sessions/$transferId/join'),
          headers: {'content-type': 'application/json'},
          body: jsonEncode({'receiverDevice': device}),
        )
        .timeout(const Duration(seconds: 20));
    return _json(res);
  }

  /// PATCH /api/sessions/{id}/update — best-effort status update.
  Future<void> updateStatus(
      String transferId, String token, String status) async {
    try {
      await http
          .patch(
            _u('/api/sessions/$transferId/update'),
            headers: {
              'content-type': 'application/json',
              'x-session-token': token,
            },
            body: jsonEncode({'status': status}),
          )
          .timeout(const Duration(seconds: 10));
    } catch (_) {
      // Status updates are cosmetic — never fail the transfer for them.
    }
  }
}

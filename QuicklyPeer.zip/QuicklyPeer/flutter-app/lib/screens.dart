import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';
import 'transfer_engine.dart';
import 'utils.dart';

/// Root screen — renders the current engine phase like a state machine.
class QuickHome extends StatefulWidget {
  const QuickHome({super.key});

  @override
  State<QuickHome> createState() => _QuickHomeState();
}

class _QuickHomeState extends State<QuickHome> {
  final TransferEngine engine = transferEngine;
  bool _showJoinForm = false;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: engine,
      builder: (context, _) {
        if (engine.phase == Phase.idle) _showJoinForm = _showJoinForm;
        return Scaffold(
          appBar: AppBar(
            title: const Text('QuicklyPeer',
                style: TextStyle(fontWeight: FontWeight.bold)),
            actions: [
              if (engine.phase != Phase.idle)
                IconButton(
                  tooltip: 'Home',
                  icon: const Icon(Icons.home_outlined),
                  onPressed: () {
                    setState(() => _showJoinForm = false);
                    engine.goHome();
                  },
                ),
            ],
          ),
          body: _body(),
        );
      },
    );
  }

  Widget _body() {
    switch (engine.phase) {
      case Phase.idle:
        return _showJoinForm
            ? const ReceiveJoinScreen()
            : const HomeBody();
      case Phase.senderWaiting:
        return const SendWaitingScreen();
      case Phase.senderIncoming:
        return const SenderIncomingScreen();
      case Phase.senderConnected:
        return const SenderConnectedScreen();
      case Phase.senderRequesting:
        return const ProgressScreen();
      case Phase.receiverJoining:
      case Phase.receiverWaiting:
        return const ReceiverWaitingScreen(joining: false);
      case Phase.receiverConnected:
        return const ReceiverWaitingScreen(joining: true);
      case Phase.receiverConfirm:
        return const ReceiverConfirmScreen();
      case Phase.transferring:
        return const ProgressScreen();
      case Phase.done:
        return const DoneScreen();
      case Phase.error:
        return const ErrorScreen();
    }
  }
}

// ---------------------------------------------------------------------------
// Shared bits
// ---------------------------------------------------------------------------

class SoftNotice extends StatelessWidget {
  final String text;
  const SoftNotice(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.tertiaryContainer,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(text, style: const TextStyle(fontSize: 13)),
    );
  }
}

class StatusChip extends StatelessWidget {
  final bool ok;
  final String label;
  const StatusChip({super.key, required this.ok, required this.label});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: ok ? colors.secondaryContainer : colors.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(ok ? Icons.check_circle : Icons.circle_outlined,
              size: 14, color: ok ? colors.primary : colors.outline),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(fontSize: 12)),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// HOME
// ---------------------------------------------------------------------------

class HomeBody extends StatefulWidget {
  const HomeBody({super.key});

  @override
  State<HomeBody> createState() => _HomeBodyState();
}

class _HomeBodyState extends State<HomeBody> {
  final _urlCtrl = TextEditingController();
  bool _loadingPrefs = true;
  bool _picking = false;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (!mounted) return;
      setState(() {
        _urlCtrl.text = p.getString('server_url') ?? '';
        _loadingPrefs = false;
      });
    });
  }

  @override
  void dispose() {
    _urlCtrl.dispose();
    super.dispose();
  }

  Future<void> _saveUrl() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('server_url', _urlCtrl.text.trim());
  }

  String? _validatedUrl() {
    final url = normalizeBaseUrl(_urlCtrl.text);
    if (url.isEmpty) return null;
    return url;
  }

  Future<void> _send() async {
    final url = _validatedUrl();
    if (url == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Enter your QuicklyPeer server URL first')));
      return;
    }
    if (_picking) return;
    setState(() => _picking = true);
    try {
      final result = await FilePicker.platform
          .pickFiles(allowMultiple: true, withData: false);
      final paths = result?.paths.whereType<String>().toList() ?? [];
      if (!mounted) return;
      if (paths.isEmpty) return;
      await _saveUrl();
      await transferEngine.startAsSender(url, paths);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('File picking failed: $e')));
      }
    } finally {
      if (mounted) setState(() => _picking = false);
    }
  }

  void _receive() {
    final url = _validatedUrl();
    if (url == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Enter your QuicklyPeer server URL first')));
      return;
    }
    _saveUrl();
    setState(() => _showJoinForm = true);
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 8),
            Icon(Icons.swap_vert_circle_outlined,
                size: 72, color: colors.primary),
            const SizedBox(height: 8),
            Text(
              'QuicklyPeer',
              textAlign: TextAlign.center,
              style: Theme.of(context)
                  .textTheme
                  .headlineMedium
                  ?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            Text(
              'On the same WiFi or across the internet — files go '
              'device-to-device, never stored on a server.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 24),
            TextField(
              controller: _urlCtrl,
              enabled: !_loadingPrefs,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(
                labelText: 'Server URL',
                hintText: 'https://your-quicklypeer-server-url',
                prefixIcon: Icon(Icons.dns_outlined),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(56)),
              onPressed: _picking ? null : _send,
              icon: _picking
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.upload_outlined),
              label: Text(_picking ? 'Pick files…' : 'Send Files',
                  style: const TextStyle(fontSize: 16)),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(56)),
              onPressed: _receive,
              icon: const Icon(Icons.download_outlined),
              label:
                  const Text('Receive Files', style: TextStyle(fontSize: 16)),
            ),
            const SizedBox(height: 24),
            Text(
              'How it works\n'
              '1. Sender picks files and gets a Transfer ID\n'
              '2. Receiver enters the ID to connect\n'
              '3. Sender approves the connection\n'
              '4. Receiver accepts the transfer — files are saved automatically',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// RECEIVE — enter Transfer ID
// ---------------------------------------------------------------------------

class ReceiveJoinScreen extends StatefulWidget {
  const ReceiveJoinScreen({super.key});

  @override
  State<ReceiveJoinScreen> createState() => _ReceiveJoinScreenState();
}

class _ReceiveJoinScreenState extends State<ReceiveJoinScreen> {
  final _idCtrl = TextEditingController();

  @override
  void dispose() {
    _idCtrl.dispose();
    super.dispose();
  }

  void _join() async {
    final raw = _idCtrl.text;
    if (raw.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Enter the Transfer ID first')));
      return;
    }
    final prefs = await SharedPreferences.getInstance();
    final url = normalizeBaseUrl(prefs.getString('server_url') ?? '');
    if (url.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Server URL missing — go back and set it')));
      }
      return;
    }
    await transferEngine.joinAsReceiver(url, raw);
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 16),
            Icon(Icons.pin_outlined,
                size: 64, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 12),
            Text('Enter Transfer ID',
                textAlign: TextAlign.center,
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text(
              'Ask the sender for the ID shown on their screen.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _idCtrl,
              textCapitalization: TextCapitalization.characters,
              textInputAction: TextInputAction.done,
              onSubmitted: (_) => _join(),
              maxLength: 12,
              style: const TextStyle(
                  fontSize: 28, fontWeight: FontWeight.bold, letterSpacing: 6),
              decoration: const InputDecoration(
                hintText: 'ABC123',
                counterText: '',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(52)),
              onPressed: _join,
              icon: const Icon(Icons.link),
              label: const Text('Connect', style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// SENDER — waiting with big Transfer ID
// ---------------------------------------------------------------------------

class SendWaitingScreen extends StatelessWidget {
  const SendWaitingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final engine = transferEngine;
    final colors = Theme.of(context).colorScheme;
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (engine.notice != null) SoftNotice(engine.notice!),
            Text('Your Transfer ID',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 16),
            GestureDetector(
              onTap: () {
                Clipboard.setData(
                    ClipboardData(text: engine.transferId ?? ''));
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Transfer ID copied')));
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 28, horizontal: 12),
                decoration: BoxDecoration(
                  color: colors.secondaryContainer,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    engine.transferId ?? '------',
                    style: TextStyle(
                      fontSize: 64,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 8,
                      color: colors.primary,
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text('Tap the ID to copy it',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                StatusChip(
                    ok: engine.signalingOnline,
                    label: engine.signalingOnline
                        ? 'Connected to server'
                        : 'Connecting…'),
              ],
            ),
            const SizedBox(height: 28),
            const CircularProgressIndicator(),
            const SizedBox(height: 16),
            Text('Waiting for a receiver to join…',
                textAlign: TextAlign.center),
            const SizedBox(height: 24),
            Text(
              '${engine.files.length} file(s) ready: '
              '${engine.files.fold<int>(0, (s, f) => s + f.meta.filesize)} bytes',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// SENDER — approve / reject incoming receiver
// ---------------------------------------------------------------------------

class SenderIncomingScreen extends StatelessWidget {
  const SenderIncomingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final engine = transferEngine;
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Icon(Icons.person_pin_circle_outlined,
              size: 72, color: Theme.of(context).colorScheme.primary),
          const SizedBox(height: 16),
          Text('A receiver wants to connect',
              textAlign: TextAlign.center,
              style: Theme.of(context)
                  .textTheme
                  .titleLarge
                  ?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text('Transfer ID ${engine.transferId ?? ''}',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 28),
          FilledButton.icon(
            style: FilledButton.styleFrom(
                minimumSize: const Size.fromHeight(54)),
            onPressed: engine.approveReceiver,
            icon: const Icon(Icons.check),
            label: const Text('Approve', style: TextStyle(fontSize: 16)),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(54)),
            onPressed: engine.rejectReceiver,
            icon: const Icon(Icons.close),
            label: const Text('Reject', style: TextStyle(fontSize: 16)),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// SENDER — connected, ready to send
// ---------------------------------------------------------------------------

class SenderConnectedScreen extends StatelessWidget {
  const SenderConnectedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final engine = transferEngine;
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (engine.notice != null) SoftNotice(engine.notice!),
            Icon(Icons.lan_outlined,
                size: 64, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 12),
            Text('Receiver connected',
                textAlign: TextAlign.center,
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            Center(
                child: StatusChip(
                    ok: engine.channelOpen,
                    label: engine.channelOpen
                        ? 'Secure channel open'
                        : 'Establishing channel…')),
            const SizedBox(height: 20),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    for (final f in engine.files)
                      ListTile(
                        dense: true,
                        leading: const Icon(Icons.insert_drive_file_outlined),
                        title: Text(f.meta.filename,
                            overflow: TextOverflow.ellipsis),
                        trailing: Text(formatBytes(f.meta.filesize)),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(54)),
              onPressed:
                  engine.channelOpen ? engine.startSend : null,
              icon: const Icon(Icons.send_outlined),
              label: Text(
                  'Send ${engine.files.length} file(s) — '
                  '${formatBytes(engine.files.fold<int>(0, (s, f) => s + f.meta.filesize))}',
                  style: const TextStyle(fontSize: 16)),
            ),
            const SizedBox(height: 8),
            const Text(
              'The receiver must accept before sending starts.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// RECEIVER — waiting for approval / sender
// ---------------------------------------------------------------------------

class ReceiverWaitingScreen extends StatelessWidget {
  final bool joining;
  const ReceiverWaitingScreen({super.key, required this.joining});

  @override
  Widget build(BuildContext context) {
    final engine = transferEngine;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (engine.notice != null) ...[
              SoftNotice(engine.notice!),
            ],
            const CircularProgressIndicator(),
            const SizedBox(height: 20),
            Text(
              joining
                  ? 'Connected. Waiting for the sender…'
                  : 'Requesting connection…\nWaiting for the sender to approve.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            Text('Transfer ID ${engine.transferId ?? ''}',
                style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// RECEIVER — accept / decline incoming files
// ---------------------------------------------------------------------------

class ReceiverConfirmScreen extends StatelessWidget {
  const ReceiverConfirmScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final engine = transferEngine;
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Icon(Icons.move_to_inbox_outlined,
                size: 64, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 12),
            Text('Incoming file transfer',
                textAlign: TextAlign.center,
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text('Accept these files?',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  children: [
                    for (final f in engine.files)
                      ListTile(
                        dense: true,
                        leading: const Icon(Icons.insert_drive_file_outlined),
                        title: Text(f.meta.filename,
                            overflow: TextOverflow.ellipsis),
                        subtitle: Text(f.meta.mimeType,
                            style: const TextStyle(fontSize: 11)),
                        trailing: Text(formatBytes(f.meta.filesize)),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Total: '
              '${formatBytes(engine.files.fold<int>(0, (s, f) => s + f.meta.filesize))} — '
              'files are saved automatically after download.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(54),
                  backgroundColor:
                      Theme.of(context).colorScheme.primary),
              onPressed: engine.acceptIncoming,
              icon: const Icon(Icons.check_circle_outline),
              label: const Text('Accept', style: TextStyle(fontSize: 16)),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(
                  minimumSize: const Size.fromHeight(54)),
              onPressed: engine.declineIncoming,
              icon: const Icon(Icons.block_outlined),
              label: const Text('Decline', style: TextStyle(fontSize: 16)),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// PROGRESS (sender + receiver)
// ---------------------------------------------------------------------------

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final engine = transferEngine;
    final isSender = engine.role == 'sender';
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (engine.notice != null) SoftNotice(engine.notice!),
          Text(
            isSender && engine.phase == Phase.senderRequesting
                ? 'Waiting for the receiver to accept…'
                : (isSender ? 'Sending…' : 'Receiving…'),
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 4),
          Text(
            engine.phase == Phase.transferring
                ? '${formatBytes(engine.speedBps)}/s'
                : 'Secure peer-to-peer channel',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 16),
          Expanded(
            child: ListView.builder(
              itemCount: engine.files.length,
              itemBuilder: (context, i) {
                final f = engine.files[i];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(f.meta.filename,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w600)),
                          ),
                          Text(
                              '${(f.ratio * 100).toStringAsFixed(0)}%',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Theme.of(context)
                                      .colorScheme
                                      .primary)),
                        ],
                      ),
                      const SizedBox(height: 6),
                      LinearProgressIndicator(
                          value: f.ratio, minHeight: 8,
                          borderRadius: BorderRadius.circular(4)),
                      const SizedBox(height: 4),
                      Text(
                        '${formatBytes(f.received)} / ${formatBytes(f.meta.filesize)}'
                        '${f.savedPath != null ? '  •  saved' : ''}',
                        style: const TextStyle(
                            fontSize: 11, color: Colors.grey),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          if (isSender && engine.phase == Phase.transferring)
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: engine.paused
                        ? engine.resumeTransfer
                        : engine.pauseTransfer,
                    icon: Icon(engine.paused
                        ? Icons.play_arrow
                        : Icons.pause),
                    label: Text(engine.paused ? 'Resume' : 'Pause'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: engine.cancelTransfer,
                    icon: const Icon(Icons.cancel_outlined),
                    label: const Text('Cancel'),
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// DONE
// ---------------------------------------------------------------------------

class DoneScreen extends StatelessWidget {
  const DoneScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final engine = transferEngine;
    final isSender = engine.role == 'sender';
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 12),
            Icon(Icons.check_circle_outline,
                size: 80, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 12),
            Text(
              isSender ? 'All files sent!' : 'All files received & saved!',
              textAlign: TextAlign.center,
              style: Theme.of(context)
                  .textTheme
                  .headlineSmall
                  ?.copyWith(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            if (isSender)
              Text(
                '${engine.files.length} file(s) delivered securely.',
                textAlign: TextAlign.center,
              )
            else
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    children: [
                      for (final path in engine.savedPaths)
                        ListTile(
                          dense: true,
                          leading:
                              const Icon(Icons.task_alt, color: Colors.teal),
                          title: Text(path.split('/').last,
                              overflow: TextOverflow.ellipsis),
                          subtitle: Text(path,
                              style: const TextStyle(fontSize: 11),
                              overflow: TextOverflow.ellipsis),
                          trailing: IconButton(
                            tooltip: 'Share',
                            icon: const Icon(Icons.share_outlined),
                            onPressed: () {
                              try {
                                Share.shareXFiles([XFile(path)]);
                              } catch (_) {}
                            },
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            if (!isSender && engine.savedPaths.isEmpty)
              const Text('No files were saved.',
                  textAlign: TextAlign.center),
            const SizedBox(height: 24),
            FilledButton(
              style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(52)),
              onPressed: engine.goHome,
              child: const Text('Back to Home'),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// ERROR
// ---------------------------------------------------------------------------

class ErrorScreen extends StatelessWidget {
  const ErrorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final engine = transferEngine;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.error_outline,
                size: 72, color: Theme.of(context).colorScheme.error),
            const SizedBox(height: 16),
            Text('Something went wrong',
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(engine.errorMessage ?? 'Unknown error',
                textAlign: TextAlign.center),
            const SizedBox(height: 24),
            FilledButton(
              onPressed: engine.goHome,
              child: const Text('Back to Home'),
            ),
          ],
        ),
      ),
    );
  }
}

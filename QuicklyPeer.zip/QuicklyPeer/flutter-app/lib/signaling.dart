import 'package:socket_io_client/socket_io_client.dart' as IO;

/// Thin wrapper around socket.io-client for the QuicklyPeer signaling server.
///
/// The server listens on port 3003 behind the gateway; the app always talks
/// to it through `{base}/?XTransformPort=3003` with socket.io path '/'.
class Signaling {
  IO.Socket? _socket;

  Function()? onConnected;
  Function(String message)? onError;
  Function()? onDisconnected;
  Function(dynamic data)? onJoined;
  Function(dynamic data)? onReceiverRequest;
  Function(dynamic data)? onApproved;
  Function(dynamic data)? onRejected;
  Function(dynamic data)? onCancelled;
  Function(dynamic data)? onPeerLeft;
  Function(dynamic data)? onOffer;
  Function(dynamic data)? onAnswer;
  Function(dynamic data)? onIce;

  void connect(
      String base, String sessionToken, String role, Map<String, dynamic> device) {
    disconnect();
    final url = '$base/?XTransformPort=3003';
    final socket = IO.io(
      url,
      IO.OptionBuilder()
          .setTransports(['websocket', 'polling'])
          .setPath('/') // CRITICAL: server uses path '/', not '/socket.io/'
          .enableForceNew()
          .setReconnectionAttempts(10)
          .build(),
    );
    _socket = socket;

    socket.onConnect((_) {
      socket.emit('session:join', {
        'sessionToken': sessionToken,
        'role': role,
        'deviceInfo': device,
      });
      onConnected?.call();
    });
    socket.onDisconnect((_) => onDisconnected?.call());
    socket.onConnectError((e) =>
        onError?.call('Cannot reach signaling server: $e'));
    socket.on('error', (d) {
      final msg =
          (d is Map && d['message'] != null) ? d['message'].toString() : 'Signaling error';
      onError?.call(msg);
    });
    socket.on('session:joined', (d) => onJoined?.call(d));
    socket.on('receiver:request', (d) => onReceiverRequest?.call(d));
    socket.on('session:approved', (d) => onApproved?.call(d));
    socket.on('session:rejected', (d) => onRejected?.call(d));
    socket.on('session:cancelled', (d) => onCancelled?.call(d));
    socket.on('session:peer-left', (d) => onPeerLeft?.call(d));
    socket.on('webrtc:offer', (d) => onOffer?.call(d));
    socket.on('webrtc:answer', (d) => onAnswer?.call(d));
    socket.on('webrtc:ice-candidate', (d) => onIce?.call(d));
  }

  void emit(String event, Map<String, dynamic> payload) {
    _socket?.emit(event, payload);
  }

  void disconnect() {
    try {
      _socket?.dispose();
    } catch (_) {}
    _socket = null;
  }
}

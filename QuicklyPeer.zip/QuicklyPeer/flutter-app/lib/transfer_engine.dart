import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:path_provider/path_provider.dart';

import 'models.dart';
import 'rest_api.dart';
import 'signaling.dart';
import 'utils.dart';

/// Global app-lifetime engine. Screens listen to it via ListenableBuilder.
final TransferEngine transferEngine = TransferEngine();

/// QuicklyPeer transfer engine.
///
/// Implements the exact same signaling + DataChannel wire protocol as the
/// QuicklyPeer web app so browser<->app and app<->app transfers interoperate:
///
///  - REST:   POST /api/sessions, POST .../files, POST .../join, PATCH .../update
///  - Socket: session:join, receiver:request, session:approve/reject,
///            webrtc:offer/answer/ice-candidate, session:cancel/leave
///  - DataChannel (JSON text frames + raw binary chunk frames):
///            hello, transfer-request, transfer-accept, transfer-decline,
///            manifest, file-start, chunk(+binary), chunk-ack, file-end,
///            file-complete, transfer-end, pause, resume, cancel
class TransferEngine extends ChangeNotifier {
  Phase _phase = Phase.idle;
  Phase get phase => _phase;

  String? errorMessage;
  String? notice;

  String? serverBase;
  String? transferId;
  String? sessionToken;
  String? role; // 'sender' | 'receiver'
  final DeviceInfo device = const DeviceInfo();

  final List<FileProgress> files = [];
  final List<String> savedPaths = [];
  int speedBps = 0;
  bool paused = false;
  bool channelOpen = false;
  bool signalingOnline = false;

  // --- internals -----------------------------------------------------------
  RestApi? _api;
  Signaling? _sig;
  RTCPeerConnection? _pc;
  RTCDataChannel? _ch;
  String? _remoteSocketId;
  String? _pendingReceiverSocketId;

  // sender streaming state
  bool _cancelled = false;
  bool _paused = false;
  bool _streaming = false;
  int _inFlight = 0;

  // receiver state
  final Map<String, Map<int, Uint8List>> _rxChunks = {};
  String? _pendingFileId;
  int _pendingOffset = 0;

  // speed sampling
  Timer? _speedTimer;
  int _bytesThisSecond = 0;
  DateTime _lastProgressNotify = DateTime.fromMillisecondsSinceEpoch(0);

  static const int _chunkSize = 64 * 1024; // 64 KB — safe on all WebRTC stacks
  static const int _highWater = 4 * 1024 * 1024; // pause above 4 MB in flight

  // =========================================================================
  // SENDER
  // =========================================================================

  /// Pick files is done in the UI; this starts a send session.
  Future<void> startAsSender(String base, List<String> paths) async {
    reset();
    serverBase = base;
    role = 'sender';
    _phase = Phase.senderWaiting;
    notifyListeners();
    try {
      _api = RestApi(base);
      final created = await _api!.createSession(device.toJson());
      transferId = created['transferId']?.toString();
      sessionToken = created['sessionToken']?.toString();
      if (transferId == null || sessionToken == null) {
        throw Exception('Server did not return a Transfer ID');
      }
      files.clear();
      for (final p in paths) {
        final f = File(p);
        final name = p.split('/').last;
        final meta = FileMeta(
          id: randomHex(16),
          filename: name,
          filesize: f.lengthSync(),
          mimeType: mimeFromFilename(name),
        );
        files.add(FileProgress(meta: meta, localPath: p));
      }
      await _api!.registerFiles(
          transferId!, sessionToken!, files.map((e) => e.meta.toJson()).toList());
      _connectSignaling('sender');
    } catch (e) {
      _fail(_cleanError(e, 'Could not create the session'));
    }
  }

  /// Sender: approve the receiver's connection request.
  void approveReceiver() {
    final socketId = _pendingReceiverSocketId;
    if (socketId == null) return;
    _sig?.emit('session:approve', {
      'sessionToken': sessionToken,
      'receiverSocketId': socketId,
    });
    notice = null;
    notifyListeners();
  }

  /// Sender: reject the receiver's connection request.
  void rejectReceiver() {
    final socketId = _pendingReceiverSocketId;
    if (socketId != null) {
      _sig?.emit('session:reject', {
        'sessionToken': sessionToken,
        'receiverSocketId': socketId,
        'reason': 'rejected-by-sender',
      });
    }
    _pendingReceiverSocketId = null;
    _setPhase(Phase.senderWaiting);
  }

  /// Sender: user pressed "Send N files" — ask the receiver to accept.
  void startSend() {
    if (_ch == null || !channelOpen) {
      notice = 'The channel is not connected yet.';
      notifyListeners();
      return;
    }
    _setPhase(Phase.senderRequesting);
    _sendControl({
      'type': 'transfer-request',
      'files': files.map((e) => e.meta.toJson()).toList(),
    });
  }

  Future<void> _streamAll() async {
    if (_streaming) return;
    _streaming = true;
    _cancelled = false;
    _paused = false;
    paused = false;
    _inFlight = 0;
    _setPhase(Phase.transferring);
    _api?.updateStatus(transferId!, sessionToken!, 'transferring');
    _startSpeedTimer();
    _sendControl({
      'type': 'manifest',
      'files': files.map((e) => e.meta.toJson()).toList(),
    });
    try {
      for (final fp in files) {
        if (_cancelled) break;
        fp.status = 'transferring';
        _maybeNotify();
        _sendControl({
          'type': 'file-start',
          'fileId': fp.meta.id,
          'filename': fp.meta.filename,
          'filesize': fp.meta.filesize,
          'mimeType': fp.meta.mimeType,
          'chunkSize': _chunkSize,
        });
        await _streamFile(fp);
        if (_cancelled) break;
        fp.status = 'done';
        _sendControl({'type': 'file-end', 'fileId': fp.meta.id});
      }
      _sendControl({'type': 'transfer-end'});
      _stopSpeedTimer();
      if (!_cancelled) _setPhase(Phase.done);
    } catch (e) {
      _fail(_cleanError(e, 'Sending failed'));
    } finally {
      _streaming = false;
      notifyListeners();
    }
  }

  Future<void> _streamFile(FileProgress fp) async {
    final path = fp.localPath;
    if (path == null) throw Exception('Missing local file path');
    final raf = File(path).openSync();
    try {
      int offset = 0;
      final buf = Uint8List(_chunkSize);
      while (offset < fp.meta.filesize) {
        if (_cancelled) return;
        while (_paused && !_cancelled) {
          await Future<void>.delayed(const Duration(milliseconds: 120));
        }
        if (_cancelled) return;
        // Flow control: wait while too much data is unacknowledged.
        while (_inFlight > _highWater && !_cancelled) {
          await Future<void>.delayed(const Duration(milliseconds: 30));
        }
        if (_cancelled) return;

        final size = (offset + _chunkSize > fp.meta.filesize)
            ? fp.meta.filesize - offset
            : _chunkSize;
        final read = raf.readIntoSync(buf, 0, size);
        if (read <= 0) break;
        final payload = Uint8List.fromList(
            Uint8List.sublistView(buf, 0, read)); // copy: buf is reused
        _inFlight += read;
        _sendControl({
          'type': 'chunk',
          'fileId': fp.meta.id,
          'offset': offset,
          'size': read,
        });
        await _ch?.send(RTCDataChannelMessage.fromBinary(payload));
        _bytesThisSecond += read;
        offset += read;
        fp.received = offset;
        _maybeNotify();
      }
    } finally {
      try {
        await raf.close();
      } catch (_) {}
    }
  }

  // =========================================================================
  // RECEIVER
  // =========================================================================

  /// Receiver: join a session by Transfer ID.
  Future<void> joinAsReceiver(String base, String id) async {
    reset();
    serverBase = base;
    role = 'receiver';
    transferId = id.trim().toUpperCase().replaceAll(' ', '');
    _phase = Phase.receiverJoining;
    notifyListeners();
    try {
      if (transferId == null || transferId!.isEmpty) {
        throw Exception('Please enter the Transfer ID');
      }
      _api = RestApi(base);
      final j = await _api!.joinSession(transferId!, device.toJson());
      if (j['senderConnected'] != true) {
        throw Exception(
            'Sender is not online. Ask them to keep QuicklyPeer open.');
      }
      sessionToken = j['sessionToken']?.toString();
      files.clear();
      final list = j['files'];
      if (list is List) {
        for (final f in list) {
          if (f is Map) {
            files.add(FileProgress(
                meta: FileMeta.fromJson(Map<String, dynamic>.from(f))));
          }
        }
      }
      _setPhase(Phase.receiverWaiting);
      _connectSignaling('receiver');
    } catch (e) {
      _fail(_cleanError(e, 'Could not join the session'));
    }
  }

  /// Receiver: ACCEPT the incoming file transfer.
  void acceptIncoming() {
    _sendControl({'type': 'transfer-accept'});
    _setPhase(Phase.transferring);
    _startSpeedTimer();
  }

  /// Receiver: DECLINE the incoming file transfer (stays connected).
  void declineIncoming() {
    _sendControl({'type': 'transfer-decline', 'reason': 'declined-by-receiver'});
    _setPhase(Phase.receiverConnected);
  }

  // =========================================================================
  // CONTROLS (both roles)
  // =========================================================================

  void pauseTransfer() {
    _paused = true;
    paused = true;
    _sendControl({'type': 'pause'});
    notifyListeners();
  }

  void resumeTransfer() {
    _paused = false;
    paused = false;
    _sendControl({'type': 'resume'});
    notifyListeners();
  }

  void cancelTransfer() {
    _cancelled = true;
    _paused = false;
    _sendControl({'type': 'cancel', 'reason': 'cancelled-by-user'});
    _sig?.emit('session:cancel', {'sessionToken': sessionToken});
    reset();
    notifyListeners();
  }

  void goHome() {
    reset();
    notifyListeners();
  }

  /// Close everything and return to the home screen state.
  void reset() {
    _cancelled = true;
    _paused = false;
    _streaming = false;
    _stopSpeedTimer();
    try {
      _ch?.close();
    } catch (_) {}
    try {
      _pc?.close();
    } catch (_) {}
    _sig?.disconnect();
    _ch = null;
    _pc = null;
    _sig = null;
    _api = null;
    _remoteSocketId = null;
    _pendingReceiverSocketId = null;
    _pendingFileId = null;
    _pendingOffset = 0;
    _inFlight = 0;
    _rxChunks.clear();
    _phase = Phase.idle;
    errorMessage = null;
    notice = null;
    transferId = null;
    sessionToken = null;
    speedBps = 0;
    paused = false;
    channelOpen = false;
    signalingOnline = false;
    files.clear();
    savedPaths.clear();
  }

  // =========================================================================
  // SIGNALING
  // =========================================================================

  void _connectSignaling(String r) {
    final sig = Signaling();
    _sig = sig;

    sig.onConnected = () {
      signalingOnline = true;
      notifyListeners();
    };
    sig.onDisconnected = () {
      signalingOnline = false;
      notifyListeners();
    };
    sig.onError = (msg) {
      // Soft errors surface as a notice unless we are on the home screen.
      if (_phase != Phase.idle) {
        notice = msg;
        notifyListeners();
      }
    };
    sig.onJoined = (d) {
      if (r == 'receiver') {
        sig.emit('receiver:request', {
          'sessionToken': sessionToken,
          'deviceInfo': device.toJson(),
        });
      }
    };
    sig.onReceiverRequest = (d) {
      if (r != 'sender' || d is! Map) return;
      _pendingReceiverSocketId = d['receiverSocketId']?.toString();
      _setPhase(Phase.senderIncoming);
    };
    sig.onApproved = (d) async {
      if (d is! Map) return;
      if (r == 'sender') {
        _remoteSocketId = d['receiverSocketId']?.toString();
        _setPhase(Phase.senderConnected);
        await _createSenderPeer();
      } else {
        _remoteSocketId = d['senderSocketId']?.toString();
        await _ensureReceiverPeer();
      }
    };
    sig.onRejected = (d) {
      final reason = (d is Map && d['reason'] != null)
          ? d['reason'].toString()
          : 'The sender rejected your connection request.';
      _fail(reason);
    };
    sig.onCancelled = (d) {
      final reason = (d is Map && d['reason'] != null)
          ? d['reason'].toString()
          : 'The other peer ended the session.';
      _fail(reason);
    };
    sig.onPeerLeft = (d) {
      if (_phase == Phase.transferring) {
        _fail('The other peer disconnected.');
      } else if (r == 'sender') {
        _pendingReceiverSocketId = null;
        channelOpen = false;
        _setPhase(Phase.senderWaiting);
        notice = 'The receiver disconnected. Waiting for a new receiver…';
        notifyListeners();
      }
    };
    sig.onOffer = (d) => _handleOffer(d);
    sig.onAnswer = (d) => _handleAnswer(d);
    sig.onIce = (d) => _handleIce(d);

    sig.connect(serverBase!, sessionToken!, r, device.toJson());
  }

  // =========================================================================
  // WEBRTC
  // =========================================================================

  Map<String, dynamic> _iceConfig() => {
        'iceServers': [
          {'urls': 'stun:stun.l.google.com:19302'},
          {'urls': 'stun:stun1.l.google.com:19302'},
          {'urls': 'stun:stun2.l.google.com:19302'},
        ],
        'sdpSemantics': 'unified-plan',
      };

  Future<void> _createSenderPeer() async {
    try {
      final pc = await createPeerConnection(_iceConfig());
      _pc = pc;
      pc.onIceCandidate = (c) {
        if (_remoteSocketId != null) {
          _sig?.emit('webrtc:ice-candidate', {
            'sessionToken': sessionToken,
            'to': _remoteSocketId,
            'candidate': c.toMap(),
          });
        }
      };
      pc.onConnectionState = (s) {
        if (s == RTCPeerConnectionState.RTCPeerConnectionStateFailed) {
          _fail('Peer connection failed.');
        }
      };
      final ch = await pc.createDataChannel(
          'quicklypeer-files', RTCDataChannelInit()..ordered = true);
      _ch = ch;
      _bindChannel(ch);
      ch.onDataChannelState = (st) {
        if (st == RTCDataChannelState.RTCDataChannelOpen) {
          channelOpen = true;
          notifyListeners();
        } else if (st == RTCDataChannelState.RTCDataChannelClosed) {
          channelOpen = false;
          notifyListeners();
        }
      };
      final offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      final desc = await pc.getLocalDescription();
      if (desc != null && _remoteSocketId != null) {
        _sig?.emit('webrtc:offer', {
          'sessionToken': sessionToken,
          'to': _remoteSocketId,
          'sdp': desc.toMap(),
        });
      }
    } catch (e) {
      _fail(_cleanError(e, 'WebRTC setup failed'));
    }
  }

  Future<void> _ensureReceiverPeer() async {
    if (_pc != null) return;
    try {
      final pc = await createPeerConnection(_iceConfig());
      _pc = pc;
      pc.onIceCandidate = (c) {
        if (_remoteSocketId != null) {
          _sig?.emit('webrtc:ice-candidate', {
            'sessionToken': sessionToken,
            'to': _remoteSocketId,
            'candidate': c.toMap(),
          });
        }
      };
      pc.onConnectionState = (s) {
        if (s == RTCPeerConnectionState.RTCPeerConnectionStateFailed) {
          _fail('Peer connection failed.');
        }
      };
      pc.onDataChannel = (ch) {
        _ch = ch;
        _bindChannel(ch);
        ch.onDataChannelState = (st) {
          if (st == RTCDataChannelState.RTCDataChannelOpen) {
            if (_phase == Phase.receiverWaiting ||
                _phase == Phase.receiverJoining) {
              _setPhase(Phase.receiverConnected);
            } else {
              channelOpen = true;
              notifyListeners();
            }
          }
        };
      };
    } catch (e) {
      _fail(_cleanError(e, 'WebRTC setup failed'));
    }
  }

  Future<void> _handleOffer(dynamic d) async {
    if (d is! Map) return;
    final sdpRaw = d['sdp'];
    if (sdpRaw is! Map) return;
    final from = d['from']?.toString();
    if (from != null) _remoteSocketId = from;
    try {
      await _ensureReceiverPeer();
      if (_pc == null) return;
      await _pc!.setRemoteDescription(
        RTCSessionDescription(
          sdpRaw['sdp']?.toString() ?? '',
          sdpRaw['type']?.toString() ?? 'offer',
        ),
      );
      final answer = await _pc!.createAnswer();
      await _pc!.setLocalDescription(answer);
      final desc = await _pc!.getLocalDescription();
      if (desc != null && _remoteSocketId != null) {
        _sig?.emit('webrtc:answer', {
          'sessionToken': sessionToken,
          'to': _remoteSocketId,
          'sdp': desc.toMap(),
        });
      }
    } catch (e) {
      _fail(_cleanError(e, 'WebRTC answer failed'));
    }
  }

  Future<void> _handleAnswer(dynamic d) async {
    if (d is! Map) return;
    final sdpRaw = d['sdp'];
    if (sdpRaw is! Map) return;
    try {
      await _pc?.setRemoteDescription(
        RTCSessionDescription(
          sdpRaw['sdp']?.toString() ?? '',
          sdpRaw['type']?.toString() ?? 'answer',
        ),
      );
    } catch (_) {
      // A late/unique answer can race the state machine — ignore.
    }
  }

  Future<void> _handleIce(dynamic d) async {
    if (d is! Map) return;
    final c = d['candidate'];
    if (c is! Map) return;
    try {
      await _pc?.addCandidate(RTCIceCandidate(
        c['candidate']?.toString(),
        c['sdpMid']?.toString(),
        (c['sdpMLineIndex'] as num?)?.toInt(),
      ));
    } catch (_) {
      // Late candidates are common — ignore.
    }
  }

  // =========================================================================
  // DATA CHANNEL WIRE PROTOCOL
  // =========================================================================

  void _bindChannel(RTCDataChannel ch) {
    ch.onMessage = (msg) {
      if (msg.isBinary) {
        _onBinary(msg.binary);
      } else {
        _onText(msg.text);
      }
    };
  }

  void _sendControl(Map<String, dynamic> msg) {
    try {
      _ch?.send(RTCDataChannelMessage.fromText(jsonEncode(msg)));
    } catch (_) {}
  }

  void _onText(String text) {
    Map<String, dynamic> msg;
    try {
      final decoded = jsonDecode(text);
      if (decoded is! Map<String, dynamic>) return;
      msg = decoded;
    } catch (_) {
      return;
    }
    switch (msg['type']) {
      case 'hello':
        break; // peer announced itself — nothing to do
      case 'transfer-accept':
        if (role == 'sender') _streamAll();
        break;
      case 'transfer-decline':
        if (role == 'sender') {
          notice = 'The receiver declined this transfer. You can send again.';
          _setPhase(Phase.senderConnected);
        }
        break;
      case 'chunk-ack':
        if (role == 'sender') {
          final size = (msg['size'] as num?)?.toInt() ?? 0;
          _inFlight = (_inFlight - size).clamp(0, 1 << 40);
        }
        break;
      case 'file-complete':
        break; // receiver confirmed a file — informational
      case 'transfer-request':
        if (role == 'receiver') {
          files.clear();
          final list = msg['files'];
          if (list is List) {
            for (final f in list) {
              if (f is Map) {
                files.add(
                    FileProgress(meta: FileMeta.fromJson(Map<String, dynamic>.from(f))));
              }
            }
          }
          _setPhase(Phase.receiverConfirm);
        }
        break;
      case 'manifest':
        if (role == 'receiver') {
          final list = msg['files'];
          if (list is List) {
            for (final f in list) {
              if (f is! Map) continue;
              final meta = FileMeta.fromJson(Map<String, dynamic>.from(f));
              final exists = files.any((e) => e.meta.id == meta.id);
              if (!exists) files.add(FileProgress(meta: meta));
            }
          }
          _maybeNotify();
        }
        break;
      case 'file-start':
        if (role == 'receiver') {
          final id = msg['fileId']?.toString();
          if (id == null) return;
          final exists = files.any((e) => e.meta.id == id);
          if (!exists) {
            files.add(FileProgress(
              meta: FileMeta(
                id: id,
                filename: msg['filename']?.toString() ?? 'file',
                filesize: (msg['filesize'] as num?)?.toInt() ?? 0,
                mimeType:
                    msg['mimeType']?.toString() ?? 'application/octet-stream',
              ),
            ));
          }
          _rxChunks[id] = {};
          _maybeNotify();
        }
        break;
      case 'chunk':
        if (role == 'receiver') {
          _pendingFileId = msg['fileId']?.toString();
          _pendingOffset = (msg['offset'] as num?)?.toInt() ?? 0;
        }
        break;
      case 'file-end':
        if (role == 'receiver') {
          final id = msg['fileId']?.toString();
          if (id != null) _assembleAndSave(id);
        }
        break;
      case 'transfer-end':
        if (role == 'receiver') {
          _stopSpeedTimer();
          _setPhase(Phase.done);
          _api?.updateStatus(transferId ?? '', sessionToken ?? '', 'completed');
        }
        break;
      case 'pause':
        paused = true;
        notifyListeners();
        break;
      case 'resume':
        paused = false;
        notifyListeners();
        break;
      case 'cancel':
        _cancelled = true;
        notice = 'The transfer was cancelled.';
        _stopSpeedTimer();
        reset();
        notifyListeners();
        break;
      default:
        break;
    }
  }

  void _onBinary(Uint8List data) {
    if (role != 'receiver') return;
    final id = _pendingFileId;
    if (id == null) return;
    _pendingFileId = null;
    final chunks = _rxChunks[id];
    if (chunks == null) return;
    chunks[_pendingOffset] = data;
    _bytesThisSecond += data.length;

    FileProgress? fp;
    for (final f in files) {
      if (f.meta.id == id) {
        fp = f;
        break;
      }
    }
    if (fp != null) {
      fp.received += data.length;
      if (fp.status == 'pending') fp.status = 'transferring';
    }
    _sendControl({
      'type': 'chunk-ack',
      'fileId': id,
      'offset': _pendingOffset,
      'size': data.length,
    });
    _maybeNotify();
  }

  Future<void> _assembleAndSave(String fileId) async {
    final chunks = _rxChunks.remove(fileId);
    if (chunks == null) return;

    FileProgress? fp;
    for (final f in files) {
      if (f.meta.id == fileId) {
        fp = f;
        break;
      }
    }
    final total = fp?.meta.filesize ?? 0;

    // Assemble in offset order (chunk sizes may vary).
    final out = BytesBuilder(copy: false);
    int offset = 0;
    while (true) {
      final c = chunks.remove(offset);
      if (c == null) break;
      out.add(c);
      offset += c.length;
      if (total > 0 && offset >= total) break;
    }
    final ok = total <= 0 || offset >= total;

    if (ok && fp != null) {
      try {
        final path = await _saveToDisk(fp.meta.filename, out.toBytes());
        fp.savedPath = path;
        fp.status = 'done';
        fp.received = total;
        savedPaths.add(path);
      } catch (e) {
        fp.status = 'error';
        notice = 'Could not save "${fp.meta.filename}": $e';
      }
    } else if (fp != null) {
      fp.status = 'error';
      notice = '"${fp.meta.filename}" arrived incomplete.';
    }
    _sendControl({'type': 'file-complete', 'fileId': fileId, 'ok': ok});
    notifyListeners();
  }

  /// Auto-save to disk: app-specific Downloads folder (no permissions needed).
  Future<String> _saveToDisk(String filename, Uint8List bytes) async {
    Directory dir;
    try {
      final dirs =
          await getExternalStorageDirectories(type: StorageDirectory.downloads);
      if (dirs != null && dirs.isNotEmpty) {
        dir = dirs.first;
      } else {
        dir = await getApplicationDocumentsDirectory();
      }
    } catch (_) {
      dir = await getApplicationDocumentsDirectory();
    }
    final safe = filename.replaceAll(RegExp(r'[/\\]'), '_');
    final path = '${dir.path}/$safe';
    await File(path).writeAsBytes(bytes, flush: true);
    return path;
  }

  // =========================================================================
  // HELPERS
  // =========================================================================

  void _setPhase(Phase p) {
    _phase = p;
    notice = null;
    notifyListeners();
  }

  void _fail(String message) {
    errorMessage = message;
    _phase = Phase.error;
    notifyListeners();
  }

  String _cleanError(Object e, String fallback) {
    var s = e.toString();
    if (s.startsWith('Exception: ')) s = s.substring('Exception: '.length);
    return s.isEmpty ? fallback : s;
  }

  void _startSpeedTimer() {
    _stopSpeedTimer();
    _bytesThisSecond = 0;
    _speedTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      speedBps = _bytesThisSecond;
      _bytesThisSecond = 0;
      if (_phase == Phase.transferring) notifyListeners();
    });
  }

  void _stopSpeedTimer() {
    _speedTimer?.cancel();
    _speedTimer = null;
    speedBps = 0;
  }

  void _maybeNotify() {
    final now = DateTime.now();
    if (now.difference(_lastProgressNotify).inMilliseconds >= 120) {
      _lastProgressNotify = now;
      notifyListeners();
    }
  }
}

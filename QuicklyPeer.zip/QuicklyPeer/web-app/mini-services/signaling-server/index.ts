/**
 * P2P File Transfer - Signaling Server
 *
 * Responsibilities:
 *  - Manage per-session rooms (one sender, one receiver per session)
 *  - Relay WebRTC signaling (offer / answer / ICE candidates)
 *  - Coordinate the sender-approval flow before WebRTC connects
 *  - Notify peers on join / leave / cancel
 *
 * NOTE: This server is intentionally lightweight. It does NOT touch the
 * database and does NOT relay file data. File data flows directly over the
 * WebRTC DataChannel between browsers once the connection is established.
 */

import { createServer } from 'http'
import { Server } from 'socket.io'

const httpServer = createServer()
const io = new Server(httpServer, {
  // DO NOT change the path - Caddy uses it to forward to this port.
  path: '/',
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000,
  maxHttpBufferSize: 1e6, // 1MB - signaling messages should be small
})

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------
type Role = 'sender' | 'receiver'

interface DeviceInfo {
  deviceType: string // mobile | desktop | tablet
  browser: string
  os: string
  userAgent: string
}

interface SessionRoom {
  sessionToken: string
  senderSocketId?: string
  senderDevice?: DeviceInfo
  // A single sender can have at most one connected receiver at a time,
  // but multiple receivers may request to connect while waiting for approval.
  receiverSocketId?: string
  receiverDevice?: DeviceInfo
  pending: Map<string, DeviceInfo> // receiverSocketId -> deviceInfo
}

// In-memory session registry. Sufficient for a single-node signaling server.
// (For multi-node, this would live in Redis - adapted to local memory here.)
const rooms = new Map<string, SessionRoom>()

const socketToRoom = new Map<string, string>() // socketId -> sessionToken
const socketToRole = new Map<string, Role>() // socketId -> role

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function getOrCreateRoom(sessionToken: string): SessionRoom {
  let room = rooms.get(sessionToken)
  if (!room) {
    room = { sessionToken, pending: new Map() }
    rooms.set(sessionToken, room)
  }
  return room
}

function cleanupRoomIfEmpty(sessionToken: string) {
  const room = rooms.get(sessionToken)
  if (!room) return
  if (!room.senderSocketId && !room.receiverSocketId && room.pending.size === 0) {
    rooms.delete(sessionToken)
  }
}

function removeSocket(socketId: string) {
  const sessionToken = socketToRoom.get(socketId)
  const role = socketToRole.get(socketId)
  if (!sessionToken) return

  const room = rooms.get(sessionToken)
  if (room) {
    if (role === 'sender' && room.senderSocketId === socketId) {
      room.senderSocketId = undefined
      room.senderDevice = undefined
      // Notify the receiver (if any) that the sender left
      if (room.receiverSocketId) {
        io.to(room.receiverSocketId).emit('session:cancelled', { sessionToken, reason: 'sender-left' })
      }
      // Notify pending receivers too
      for (const pendingId of room.pending.keys()) {
        io.to(pendingId).emit('session:cancelled', { sessionToken, reason: 'sender-left' })
      }
      room.pending.clear()
      room.receiverSocketId = undefined
      room.receiverDevice = undefined
    } else if (role === 'receiver') {
      if (room.receiverSocketId === socketId) {
        room.receiverSocketId = undefined
        room.receiverDevice = undefined
        if (room.senderSocketId) {
          io.to(room.senderSocketId).emit('session:peer-left', { sessionToken, socketId })
        }
      }
      room.pending.delete(socketId)
    }
    cleanupRoomIfEmpty(sessionToken)
  }
  socketToRoom.delete(socketId)
  socketToRole.delete(socketId)
}

// ---------------------------------------------------------------------------
// Connection handling
// ---------------------------------------------------------------------------
io.on('connection', (socket) => {
  console.log(`[signaling] connected: ${socket.id}`)

  // ---- Session join ------------------------------------------------------
  socket.on('session:join', (payload: { sessionToken: string; role: Role; deviceInfo?: DeviceInfo }) => {
    const { sessionToken, role, deviceInfo } = payload ?? {}
    if (!sessionToken || !role) {
      socket.emit('error', { message: 'session:join requires sessionToken and role' })
      return
    }

    const room = getOrCreateRoom(sessionToken)
    socketToRoom.set(socket.id, sessionToken)
    socketToRole.set(socket.id, role)

    if (role === 'sender') {
      // If a sender reconnects with the same token, replace the old one.
      if (room.senderSocketId && room.senderSocketId !== socket.id) {
        io.to(room.senderSocketId).emit('session:cancelled', { sessionToken, reason: 'replaced' })
      }
      room.senderSocketId = socket.id
      room.senderDevice = deviceInfo
      console.log(`[signaling] sender joined session ${sessionToken.slice(0, 8)}… (socket ${socket.id})`)

      socket.emit('session:joined', {
        sessionToken,
        role: 'sender',
        receiver: room.receiverSocketId
          ? { socketId: room.receiverSocketId, deviceInfo: room.receiverDevice }
          : null,
        pendingRequests: Array.from(room.pending.entries()).map(([socketId, info]) => ({
          socketId,
          deviceInfo: info,
        })),
      })
    } else {
      // Receiver - register presence, but DO NOT auto-connect to sender.
      // The receiver must explicitly send `receiver:request` to ask the sender
      // for approval. This implements the security gate from the plan.
      console.log(`[signaling] receiver joined session ${sessionToken.slice(0, 8)}… (socket ${socket.id})`)

      socket.emit('session:joined', {
        sessionToken,
        role: 'receiver',
        sender: room.senderSocketId
          ? { socketId: room.senderSocketId, deviceInfo: room.senderDevice }
          : null,
      })
    }
  })

  // ---- Receiver asks the sender for approval -----------------------------
  socket.on('receiver:request', (payload: { sessionToken: string; deviceInfo: DeviceInfo }) => {
    const { sessionToken, deviceInfo } = payload ?? {}
    const room = rooms.get(sessionToken ?? '')
    if (!room) {
      socket.emit('error', { message: 'Session not found' })
      return
    }
    if (!room.senderSocketId) {
      socket.emit('error', { message: 'Sender is not online yet' })
      return
    }
    room.pending.set(socket.id, deviceInfo)
    io.to(room.senderSocketId).emit('receiver:request', {
      sessionToken,
      receiverSocketId: socket.id,
      deviceInfo,
    })
    console.log(`[signaling] receiver ${socket.id} requested to join session ${sessionToken.slice(0, 8)}…`)
  })

  // ---- Sender approves / rejects a receiver ------------------------------
  socket.on('session:approve', (payload: { sessionToken: string; receiverSocketId: string }) => {
    const { sessionToken, receiverSocketId } = payload ?? {}
    const room = rooms.get(sessionToken ?? '')
    if (!room || room.senderSocketId !== socket.id) {
      socket.emit('error', { message: 'Only the sender can approve' })
      return
    }
    const info = room.pending.get(receiverSocketId)
    if (!info) {
      socket.emit('error', { message: 'No such pending receiver' })
      return
    }
    // Reject any previously connected receiver (single-receiver MVP)
    if (room.receiverSocketId && room.receiverSocketId !== receiverSocketId) {
      io.to(room.receiverSocketId).emit('session:cancelled', { sessionToken, reason: 'replaced' })
    }
    room.receiverSocketId = receiverSocketId
    room.receiverDevice = info
    room.pending.delete(receiverSocketId)
    // Clear other pending receivers
    for (const pendingId of room.pending.keys()) {
      if (pendingId !== receiverSocketId) {
        io.to(pendingId).emit('session:rejected', { sessionToken, reason: 'another-receiver-approved' })
      }
    }
    room.pending.clear()

    io.to(receiverSocketId).emit('session:approved', { sessionToken, senderSocketId: socket.id })
    // Tell the sender too (so the UI can advance)
    socket.emit('session:approved', { sessionToken, receiverSocketId })
    console.log(`[signaling] sender approved receiver ${receiverSocketId} for session ${sessionToken.slice(0, 8)}…`)
  })

  socket.on('session:reject', (payload: { sessionToken: string; receiverSocketId: string; reason?: string }) => {
    const { sessionToken, receiverSocketId, reason } = payload ?? {}
    const room = rooms.get(sessionToken ?? '')
    if (!room || room.senderSocketId !== socket.id) {
      socket.emit('error', { message: 'Only the sender can reject' })
      return
    }
    room.pending.delete(receiverSocketId)
    io.to(receiverSocketId).emit('session:rejected', { sessionToken, reason: reason ?? 'rejected-by-sender' })
    console.log(`[signaling] sender rejected receiver ${receiverSocketId}`)
  })

  // ---- WebRTC signaling relay -------------------------------------------
  // All three are simple point-to-point relays to the target socket.
  const relay = (event: string) => (payload: { sessionToken: string; to: string; [k: string]: unknown }) => {
    const { sessionToken, to, ...rest } = payload ?? {}
    if (!sessionToken || !to) {
      socket.emit('error', { message: `${event} requires sessionToken and to` })
      return
    }
    io.to(to).emit(event, { from: socket.id, ...rest })
  }

  socket.on('webrtc:offer', relay('webrtc:offer'))
  socket.on('webrtc:answer', relay('webrtc:answer'))
  socket.on('webrtc:ice-candidate', relay('webrtc:ice-candidate'))

  // ---- Cancel / leave ----------------------------------------------------
  socket.on('session:cancel', (payload: { sessionToken: string; reason?: string }) => {
    const { sessionToken, reason } = payload ?? {}
    const room = rooms.get(sessionToken ?? '')
    if (!room) return
    // Notify everyone else in the room
    const targets = [room.senderSocketId, room.receiverSocketId, ...room.pending.keys()].filter(
      (id): id is string => !!id && id !== socket.id
    )
    targets.forEach((id) => io.to(id).emit('session:cancelled', { sessionToken, reason: reason ?? 'cancelled' }))
    removeSocket(socket.id)
    console.log(`[signaling] socket ${socket.id} cancelled session ${sessionToken?.slice(0, 8)}…`)
  })

  socket.on('session:leave', (payload: { sessionToken: string }) => {
    removeSocket(socket.id)
  })

  // ---- Disconnect --------------------------------------------------------
  socket.on('disconnect', () => {
    console.log(`[signaling] disconnected: ${socket.id}`)
    removeSocket(socket.id)
  })

  socket.on('error', (error) => {
    console.error(`[signaling] socket error (${socket.id}):`, error)
  })
})

const PORT = 3003
httpServer.listen(PORT, () => {
  console.log(`[signaling] WebSocket signaling server running on port ${PORT}`)
})

process.on('SIGTERM', () => {
  console.log('[signaling] SIGTERM, shutting down...')
  io.close(() => process.exit(0))
})
process.on('SIGINT', () => {
  console.log('[signaling] SIGINT, shutting down...')
  io.close(() => process.exit(0))
})

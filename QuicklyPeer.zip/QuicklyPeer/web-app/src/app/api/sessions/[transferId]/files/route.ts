/**
 * QuicklyPeer — Register/update the file manifest for a session.
 *
 * POST /api/sessions/[transferId]/files
 *   header: x-session-token: <sessionToken>
 *   body:   { files: FileMeta[] }
 *   ->     { ok: true, count: number }
 *
 * Only the sender (holder of the session token) may register files.
 */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ApiError, FileMeta } from '@/lib/types'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function POST(
  request: Request,
  { params }: { params: Promise<{ transferId: string }> }
) {
  const { transferId } = await params
  const sessionToken = request.headers.get('x-session-token')

  if (!sessionToken) {
    return NextResponse.json<ApiError>({ error: 'Missing session token' }, { status: 401 })
  }

  const session = await db.transferSession.findUnique({ where: { transferId } })
  if (!session || session.sessionToken !== sessionToken) {
    return NextResponse.json<ApiError>({ error: 'Unauthorized' }, { status: 403 })
  }

  let body: { files?: FileMeta[] } = {}
  try {
    body = await request.json()
  } catch {
    return NextResponse.json<ApiError>({ error: 'Invalid JSON body' }, { status: 400 })
  }

  if (!Array.isArray(body.files)) {
    return NextResponse.json<ApiError>({ error: 'files must be an array' }, { status: 400 })
  }

  // Replace the manifest atomically: delete then create.
  await db.transferFile.deleteMany({ where: { sessionId: session.id } })

  if (body.files.length > 0) {
    await db.transferFile.createMany({
      data: body.files.map((f) => ({
        sessionId: session.id,
        filename: f.filename,
        filesize: BigInt(f.filesize),
        mimeType: f.mimeType || 'application/octet-stream',
        checksum: f.checksum ?? null,
      })),
    })
  }

  return NextResponse.json({ ok: true, count: body.files.length })
}

/**
 * QuicklyPeer — Receiver joins a session by transfer ID.
 *
 * POST /api/sessions/[transferId]/join
 *   body: { receiverDevice: DeviceInfo }
 *   ->   JoinSessionResponse
 *
 * This is a lightweight lookup: it returns the session token so the receiver
 * can then connect to the signaling server. The actual approval gate happens
 * over the signaling channel (receiver:request -> session:approve).
 */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ApiError, DeviceInfo, JoinSessionResponse } from '@/lib/types'
import { markExpiredIfNeeded, serializeSession } from '@/app/api/sessions/_helpers'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function POST(
  request: Request,
  { params }: { params: Promise<{ transferId: string }> }
) {
  const { transferId } = await params

  const session = await db.transferSession.findUnique({
    where: { transferId },
    include: { files: true },
  })

  if (!session) {
    return NextResponse.json<ApiError>({ error: 'Session not found' }, { status: 404 })
  }

  if (await markExpiredIfNeeded(session)) {
    return NextResponse.json<ApiError>({ error: 'Session has expired' }, { status: 410 })
  }

  if (session.status === 'closed' || session.status === 'completed') {
    return NextResponse.json<ApiError>({ error: `Session is ${session.status}` }, { status: 410 })
  }

  // Record the receiver device info so the sender can see who's connecting.
  let body: { receiverDevice?: DeviceInfo } = {}
  try {
    body = await request.json()
  } catch {
    // body is optional
  }

  if (body.receiverDevice) {
    await db.transferSession.update({
      where: { id: session.id },
      data: { receiverDeviceJson: JSON.stringify(body.receiverDevice) },
    })
  }

  const fresh = body.receiverDevice
    ? await db.transferSession.findUnique({ where: { id: session.id }, include: { files: true } }) ?? session
    : session

  const serialized = serializeSession(fresh)

  const response: JoinSessionResponse = {
    transferId: serialized.transferId,
    sessionToken: serialized.sessionToken,
    status: serialized.status,
    senderConnected: serialized.senderConnected,
    files: serialized.files,
    expiresAt: serialized.expiresAt,
  }

  return NextResponse.json(response)
}

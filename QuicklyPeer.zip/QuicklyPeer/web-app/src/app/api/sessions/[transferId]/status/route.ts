/**
 * QuicklyPeer — Get session status by transfer ID.
 *
 * GET /api/sessions/[transferId]/status?token=<sessionToken>
 *
 * Returns the full session state (files, devices, expiry). The sessionToken
 * query param authorizes the read so the human ID alone can't leak info.
 */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ApiError } from '@/lib/types'
import { markExpiredIfNeeded, serializeSession } from '@/app/api/sessions/_helpers'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ transferId: string }> }
) {
  const { transferId } = await params

  const session = await db.transferSession.findUnique({
    where: { transferId },
    include: { files: true },
  })

  if (!session) {
    return NextResponse.json<ApiError>({ error: 'Session not found' }, { status: 404 })
  }

  await markExpiredIfNeeded(session)

  const fresh = session.status === 'expired'
    ? await db.transferSession.findUnique({ where: { id: session.id }, include: { files: true } }) ?? session
    : session

  return NextResponse.json(serializeSession(fresh))
}

/**
 * QuicklyPeer — Update session status / device connection flags.
 *
 * PATCH /api/sessions/[transferId]/update
 *   header: x-session-token: <sessionToken>
 *   body:   { status?: SessionStatus, senderConnected?: boolean, receiverConnected?: boolean }
 *   ->     { ok: true }
 *
 * The session token authorizes the mutation. Both sender and receiver hold it.
 */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ApiError, SessionStatus } from '@/lib/types'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const ALLOWED_STATUSES: SessionStatus[] = [
  'waiting', 'pending', 'connected', 'transferring', 'completed', 'closed',
]

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ transferId: string }> }
) {
  const { transferId } = await params
  const sessionToken = request.headers.get('x-session-token')

  if (!sessionToken) {
    return NextResponse.json<ApiError>({ error: 'Missing session token' }, { status: 401 })
  }

  const session = await db.transferSession.findUnique({ where: { transferId } })
  if (!session || session.sessionToken !== sessionToken) {
    return NextResponse.json<ApiError>({ error: 'Unauthorized' }, { status: 403 })
  }

  let body: {
    status?: SessionStatus
    senderConnected?: boolean
    receiverConnected?: boolean
  } = {}
  try {
    body = await request.json()
  } catch {
    return NextResponse.json<ApiError>({ error: 'Invalid JSON body' }, { status: 400 })
  }

  const data: Record<string, unknown> = {}
  if (typeof body.status === 'string') {
    if (!ALLOWED_STATUSES.includes(body.status)) {
      return NextResponse.json<ApiError>({ error: `Invalid status: ${body.status}` }, { status: 400 })
    }
    data.status = body.status
  }
  if (typeof body.senderConnected === 'boolean') data.senderConnected = body.senderConnected
  if (typeof body.receiverConnected === 'boolean') data.receiverConnected = body.receiverConnected

  if (Object.keys(data).length === 0) {
    return NextResponse.json<ApiError>({ error: 'No fields to update' }, { status: 400 })
  }

  await db.transferSession.update({ where: { id: session.id }, data })

  return NextResponse.json({ ok: true })
}

/**
 * QuicklyPeer — Session API route helpers
 *
 * Shared serialization + expiry cleanup used by all session API routes.
 */

import { db } from '@/lib/db'
import { isExpired } from '@/lib/server-utils'
import type { DeviceInfo, FileMeta, SessionStatus, SessionStatusResponse, TransferFile } from '@/lib/types'

/** Parse a JSON column that may be null or malformed. */
function parseJson<T>(value: string | null, fallback: T): T {
  if (!value) return fallback
  try {
    return JSON.parse(value) as T
  } catch {
    return fallback
  }
}

/** Convert a DB session row (with files) into the API response shape. */
export function serializeSession(
  row: {
    id: string
    sessionToken: string
    transferId: string
    status: string
    senderConnected: boolean
    receiverConnected: boolean
    senderDeviceJson: string | null
    receiverDeviceJson: string | null
    createdAt: Date
    expiresAt: Date
    files?: Array<{
      id: string
      sessionId: string
      filename: string
      filesize: bigint
      mimeType: string
      checksum: string | null
      createdAt: Date
    }>
  }
): SessionStatusResponse {
  const files: TransferFile[] = (row.files ?? []).map((f) => {
    const meta: TransferFile = {
      id: f.id,
      sessionId: f.sessionId,
      filename: f.filename,
      filesize: Number(f.filesize),
      mimeType: f.mimeType,
      checksum: f.checksum ?? undefined,
      createdAt: f.createdAt.toISOString(),
    }
    return meta
  })

  return {
    transferId: row.transferId,
    sessionToken: row.sessionToken,
    status: row.status as SessionStatus,
    senderConnected: row.senderConnected,
    receiverConnected: row.receiverConnected,
    senderDevice: row.senderDeviceJson ? parseJson<DeviceInfo | null>(row.senderDeviceJson, null) : null,
    receiverDevice: row.receiverDeviceJson ? parseJson<DeviceInfo | null>(row.receiverDeviceJson, null) : null,
    files,
    expiresAt: row.expiresAt.toISOString(),
    createdAt: row.createdAt.toISOString(),
  }
}

/**
 * Lazily mark expired sessions as expired so the API reflects reality.
 * Cheap to call on every read.
 */
export async function markExpiredIfNeeded(row: { status: string; expiresAt: Date }) {
  if (row.status !== 'expired' && isExpired(row.expiresAt)) {
    await db.transferSession.update({
      where: { id: row.id },
      data: { status: 'expired' },
    }).catch(() => {})
    return true
  }
  return false
}

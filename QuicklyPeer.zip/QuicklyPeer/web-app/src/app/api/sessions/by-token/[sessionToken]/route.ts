/**
 * QuicklyPeer — Resolve a session by its secure token (used by /join/:token links).
 *
 * GET /api/sessions/by-token/[sessionToken]
 *   -> SessionStatusResponse
 */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { ApiError } from '@/lib/types'
import { markExpiredIfNeeded, serializeSession } from '@/app/api/sessions/_helpers'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ sessionToken: string }> }
) {
  const { sessionToken } = await params

  const session = await db.transferSession.findUnique({
    where: { sessionToken },
    include: { files: true },
  })

  if (!session) {
    return NextResponse.json<ApiError>({ error: 'Session not found' }, { status: 404 })
  }

  await markExpiredIfNeeded(session)

  const fresh = session.status === 'expired'
    ? await db.transferSession.findUnique({ where: { id: session.id }, include: { files: true } }) ?? session
    : session

  return NextResponse.json(serializeSession(fresh))
}

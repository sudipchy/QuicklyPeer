/**
 * QuicklyPeer — Create a new transfer session.
 *
 * POST /api/sessions
 *   body: { files?: FileMeta[], senderDevice?: DeviceInfo }
 *   -> CreateSessionResponse
 *
 * The sender creates a session here, then opens a WebSocket to the signaling
 * server using the returned sessionToken.
 */

import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import {
  defaultExpiry,
  generateSessionToken,
  generateTransferId,
} from '@/lib/server-utils'
import type { CreateSessionResponse, DeviceInfo, FileMeta } from '@/lib/types'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function POST(request: Request) {
  let body: { files?: FileMeta[]; senderDevice?: DeviceInfo } = {}
  try {
    body = await request.json()
  } catch {
    // empty body is fine — the sender may register files later
  }

  const transferId = generateTransferId()
  const sessionToken = generateSessionToken()
  const expiresAt = defaultExpiry()

  // Make sure the human-friendly ID is unique (collision chance ~1e-9, but be safe).
  let attempts = 0
  while (
    await db.transferSession.findUnique({ where: { transferId } })
  ) {
    const retry = generateTransferId()
    if (++attempts > 5) break
    // reassign in next iteration
    void retry
  }

  const session = await db.transferSession.create({
    data: {
      sessionToken,
      transferId,
      status: 'waiting',
      expiresAt,
      senderConnected: true, // sender is creating it right now
      senderDeviceJson: body.senderDevice ? JSON.stringify(body.senderDevice) : null,
    },
  })

  // Optional: register the file manifest up front (sender can also add later).
  if (Array.isArray(body.files) && body.files.length > 0) {
    await db.transferFile.createMany({
      data: body.files.map((f) => ({
        sessionId: session.id,
        filename: f.filename,
        filesize: BigInt(f.filesize),
        mimeType: f.mimeType || 'application/octet-stream',
        checksum: f.checksum ?? null,
      })),
    })
  }

  const shareUrl = `/?join=${sessionToken}`

  const response: CreateSessionResponse = {
    transferId,
    sessionToken,
    shareUrl,
    expiresAt: expiresAt.toISOString(),
  }

  return NextResponse.json(response)
}

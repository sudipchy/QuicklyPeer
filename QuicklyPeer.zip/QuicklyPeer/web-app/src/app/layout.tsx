import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "QuicklyPeer — Unlimited P2P File Transfer",
  description: "QuicklyPeer sends files directly between browsers over WebRTC. No size limits, no uploads, no servers storing your data. Fast, private, peer-to-peer.",
  keywords: ["QuicklyPeer", "P2P file transfer", "WebRTC", "send files", "share files", "peer to peer"],
  authors: [{ name: "QuicklyPeer" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "QuicklyPeer — Unlimited P2P File Transfer",
    description: "Send files directly between browsers over WebRTC. No size limits, no uploads.",
    siteName: "QuicklyPeer",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "QuicklyPeer — Unlimited P2P File Transfer",
    description: "Send files directly between browsers over WebRTC. No size limits, no uploads.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}

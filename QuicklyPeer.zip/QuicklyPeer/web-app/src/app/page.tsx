"use client"

import { useEffect, useRef } from "react"
import { useTransferStore } from "@/lib/store"
import { AppHeader } from "@/components/transfer/AppHeader"
import { AppFooter } from "@/components/transfer/AppFooter"
import { HomeScreen } from "@/components/transfer/HomeScreen"
import { SenderWaitingScreen } from "@/components/transfer/SenderWaitingScreen"
import { SenderPendingScreen } from "@/components/transfer/SenderPendingScreen"
import { SenderConnectedScreen } from "@/components/transfer/SenderConnectedScreen"
import { SenderRequestingScreen } from "@/components/transfer/SenderRequestingScreen"
import { ReceiverReadyScreen } from "@/components/transfer/ReceiverReadyScreen"
import { ReceiverConfirmScreen } from "@/components/transfer/ReceiverConfirmScreen"
import { ReceiverWaitingScreen } from "@/components/transfer/ReceiverWaitingScreen"
import { TransferProgressScreen } from "@/components/transfer/TransferProgressScreen"
import { TransferDoneScreen } from "@/components/transfer/TransferDoneScreen"
import { ErrorScreen } from "@/components/transfer/ErrorScreen"

export default function Home() {
  const view = useTransferStore((s) => s.view)
  const joinByToken = useTransferStore((s) => s.joinByToken)
  const joinedRef = useRef(false)

  // Auto-join when the URL contains ?join=<token> (share-link entry point).
  useEffect(() => {
    if (joinedRef.current) return
    if (typeof window === "undefined") return
    const params = new URLSearchParams(window.location.search)
    const token = params.get("join")
    if (token) {
      joinedRef.current = true
      joinByToken(token)
      // Clean the URL so a refresh doesn't re-trigger the join.
      const url = new URL(window.location.href)
      url.searchParams.delete("join")
      window.history.replaceState({}, "", url.toString())
    }
  }, [joinByToken])

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <AppHeader />
      <main className="flex-1 px-4 py-2">
        {renderView(view)}
      </main>
      <AppFooter />
    </div>
  )
}

function renderView(view: string) {
  switch (view) {
    case "home":
      return <HomeScreen />
    case "sender-waiting":
      return <SenderWaitingScreen />
    case "sender-pending":
      return <SenderPendingScreen />
    case "sender-connected":
      return <SenderConnectedScreen />
    case "sender-requesting":
      return <SenderRequestingScreen />
    case "sender-transferring":
    case "receiver-transferring":
      return <TransferProgressScreen />
    case "sender-done":
    case "receiver-done":
      return <TransferDoneScreen />
    case "receiver-joining":
    case "receiver-waiting":
      return <ReceiverWaitingScreen />
    case "receiver-connected":
      return <ReceiverReadyScreen />
    case "receiver-confirm":
      return <ReceiverConfirmScreen />
    case "error":
      return <ErrorScreen />
    default:
      return <HomeScreen />
  }
}

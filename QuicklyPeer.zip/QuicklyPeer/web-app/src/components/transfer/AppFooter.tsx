"use client"

import { Github, ShieldCheck, Zap } from "lucide-react"

/**
 * Footer with quick marketing + privacy notes. Sticky to the bottom via the
 * page layout (flex flex-col + mt-auto).
 */
export function AppFooter() {
  return (
    <footer className="mt-auto border-t border-border bg-background">
      <div className="mx-auto flex w-full max-w-5xl flex-col items-center justify-between gap-3 px-4 py-5 text-xs text-muted-foreground sm:flex-row">
        <div className="flex items-center gap-1.5">
          <span className="flex size-5 items-center justify-center rounded bg-primary text-primary-foreground">
            <Zap className="size-3" />
          </span>
          <span className="font-medium text-foreground">QuicklyPeer</span>
          <span>· peer-to-peer file transfer</span>
        </div>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1">
            <ShieldCheck className="size-3.5" />
            WebRTC encrypted · sender-approved
          </span>
          <a
            href="https://webrtc.org"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 transition-colors hover:text-foreground"
          >
            <Github className="size-3.5" />
            Built on WebRTC
          </a>
        </div>
      </div>
    </footer>
  )
}

"use client"

import { Zap, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useTransferStore } from "@/lib/store"

/**
 * Top app bar. Shows the QuicklyPeer brand and a Home button when the user is
 * mid-flow so they can bail out at any time.
 */
export function AppHeader() {
  const view = useTransferStore((s) => s.view)
  const goHome = useTransferStore((s) => s.goHome)
  const showHome = view !== "home"

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="mx-auto flex h-14 w-full max-w-5xl items-center justify-between px-4">
        <button
          onClick={goHome}
          className="flex items-center gap-2 text-left"
          aria-label="QuicklyPeer home"
        >
          <span className="flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Zap className="size-4" />
          </span>
          <span className="text-sm font-bold tracking-tight">QuicklyPeer</span>
        </button>

        {showHome && (
          <Button variant="ghost" size="sm" onClick={goHome}>
            <Home className="size-4" />
            Home
          </Button>
        )}
      </div>
    </header>
  )
}

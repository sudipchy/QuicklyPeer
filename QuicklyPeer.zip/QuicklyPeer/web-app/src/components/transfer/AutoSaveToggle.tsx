"use client"

import { HardDriveDownload } from "lucide-react"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { useTransferStore } from "@/lib/store"

/**
 * Receiver-only toggle: when ON, every file that finishes transferring is
 * automatically saved to disk (the browser's default Downloads folder).
 */
export function AutoSaveToggle({ className }: { className?: string }) {
  const autoSave = useTransferStore((s) => s.autoSave)
  const setAutoSave = useTransferStore((s) => s.setAutoSave)
  const role = useTransferStore((s) => s.role)

  if (role !== "receiver") return null

  return (
    <div
      className={
        "flex items-center justify-between gap-3 rounded-lg border border-border bg-muted/30 px-3 py-2.5 " +
        (className ?? "")
      }
    >
      <div className="flex items-center gap-2.5">
        <HardDriveDownload className="size-4 text-primary" />
        <div>
          <Label htmlFor="auto-save" className="text-sm font-medium cursor-pointer">
            Auto-save to disk
          </Label>
          <p className="text-xs text-muted-foreground">
            Files save automatically to your Downloads folder.
          </p>
        </div>
      </div>
      <Switch id="auto-save" checked={autoSave} onCheckedChange={setAutoSave} />
    </div>
  )
}

"use client"

import { AlertTriangle, Home, RotateCcw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useTransferStore } from "@/lib/store"

/**
 * Generic error view. Surfaces the store's errorMessage and offers a reset.
 */
export function ErrorScreen() {
  const errorMessage = useTransferStore((s) => s.errorMessage)
  const goHome = useTransferStore((s) => s.goHome)
  const role = useTransferStore((s) => s.role)

  return (
    <div className="mx-auto flex w-full max-w-lg py-6">
      <Card className="w-full">
        <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
          <div className="flex size-14 items-center justify-center rounded-full bg-destructive/10 text-destructive">
            <AlertTriangle className="size-7" />
          </div>
          <h2 className="text-xl font-bold">Something went wrong</h2>
          <p className="max-w-sm text-sm text-muted-foreground">
            {errorMessage || "An unexpected error occurred."}
          </p>
          <div className="flex gap-2 pt-2">
            {role && (
              <Button variant="outline" onClick={() => window.location.reload()}>
                <RotateCcw className="size-4" />
                Retry
              </Button>
            )}
            <Button onClick={goHome}>
              <Home className="size-4" />
              Back to Home
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

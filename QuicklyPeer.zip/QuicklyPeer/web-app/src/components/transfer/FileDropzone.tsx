"use client"

import { useCallback, useRef, useState } from "react"
import { UploadCloud, FileText, X } from "lucide-react"
import { cn } from "@/lib/utils"
import { formatBytes } from "@/lib/transfer-utils"
import { Button } from "@/components/ui/button"

interface FileDropzoneProps {
  files: File[]
  onFilesChange: (files: File[]) => void
  className?: string
  /** Disable when transfer has started. */
  disabled?: boolean
}

/**
 * Drag-and-drop + click-to-browse file picker. Supports selecting many files
 * of any size — we never read them into memory eagerly, only their File handles.
 */
export function FileDropzone({ files, onFilesChange, className, disabled }: FileDropzoneProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const [dragging, setDragging] = useState(false)

  const handleFiles = useCallback(
    (incoming: FileList | null) => {
      if (!incoming || incoming.length === 0) return
      const dedup = new Map<string, File>()
      files.forEach((f) => dedup.set(`${f.name}:${f.size}:${f.lastModified}`, f))
      Array.from(incoming).forEach((f) =>
        dedup.set(`${f.name}:${f.size}:${f.lastModified}`, f)
      )
      onFilesChange(Array.from(dedup.values()))
    },
    [files, onFilesChange]
  )

  const removeAt = (index: number) => {
    const next = [...files]
    next.splice(index, 1)
    onFilesChange(next)
  }

  return (
    <div className={cn("space-y-3", className)}>
      <div
        role="button"
        tabIndex={0}
        onClick={() => !disabled && inputRef.current?.click()}
        onKeyDown={(e) => {
          if ((e.key === "Enter" || e.key === " ") && !disabled) inputRef.current?.click()
        }}
        onDragOver={(e) => {
          e.preventDefault()
          if (!disabled) setDragging(true)
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault()
          setDragging(false)
          if (!disabled) handleFiles(e.dataTransfer.files)
        }}
        className={cn(
          "flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-border bg-muted/40 p-8 text-center transition-colors",
          dragging && "border-primary bg-primary/5",
          disabled && "cursor-not-allowed opacity-60",
          !disabled && "cursor-pointer hover:border-primary/60 hover:bg-muted/60"
        )}
      >
        <UploadCloud className="size-8 text-muted-foreground" />
        <div className="text-sm font-medium">
          Drop files here, or <span className="text-primary underline-offset-2">browse</span>
        </div>
        <div className="text-xs text-muted-foreground">
          Any number of files · any size · stays between browsers
        </div>
        <input
          ref={inputRef}
          type="file"
          multiple
          className="hidden"
          disabled={disabled}
          onChange={(e) => {
            handleFiles(e.target.files)
            e.target.value = ""
          }}
        />
      </div>

      {files.length > 0 && (
        <ul className="max-h-72 space-y-2 overflow-y-auto pr-1">
          {files.map((f, i) => (
            <li
              key={`${f.name}-${i}`}
              className="flex items-center gap-3 rounded-lg border border-border bg-card p-3"
            >
              <div className="flex size-9 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
                <FileText className="size-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="truncate text-sm font-medium">{f.name}</div>
                <div className="text-xs text-muted-foreground">
                  {formatBytes(f.size)} · {f.type || "unknown type"}
                </div>
              </div>
              {!disabled && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-8"
                  onClick={() => removeAt(i)}
                  aria-label={`Remove ${f.name}`}
                >
                  <X className="size-4" />
                </Button>
              )}
            </li>
          ))}
        </ul>
      )}
    </div>
  )
}

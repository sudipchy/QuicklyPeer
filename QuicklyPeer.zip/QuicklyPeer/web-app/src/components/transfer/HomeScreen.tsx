"use client"

import { useState } from "react"
import { ArrowRight, ArrowLeft, ArrowDownToLine, Zap, ShieldCheck, Wifi, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { useTransferStore } from "@/lib/store"

/**
 * Landing screen: choose Send or Receive. The receive form lets the user
 * paste a human-friendly Transfer ID (e.g. 482-731-905) and connect to the
 * sender. The sender must then approve, and finally the receiver accepts
 * the incoming file transfer before any bytes flow.
 */
export function HomeScreen() {
  const initSender = useTransferStore((s) => s.initSender)
  const joinByTransferId = useTransferStore((s) => s.joinByTransferId)

  const [mode, setMode] = useState<"choose" | "receive">("choose")
  const [transferId, setTransferId] = useState("")
  const [joining, setJoining] = useState(false)

  const handleReceive = () => {
    // Accept "482731905", "482 731 905" and "482-731-905" alike.
    const cleaned = transferId.trim().replace(/[\s\u2013\u2014]+/g, "")
    if (!cleaned || joining) return
    setJoining(true)
    joinByTransferId(cleaned)
  }

  const handleReceiveClick = () => {
    setMode("receive")
    setTransferId("")
  }

  return (
    <div className="mx-auto flex w-full max-w-xl flex-col items-center gap-8 py-6">
      {/* Hero */}
      <div className="flex flex-col items-center gap-3 text-center">
        <div className="flex size-16 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-sm">
          <Zap className="size-8" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">QuicklyPeer</h1>
        <p className="max-w-md text-balance text-muted-foreground">
          Send files directly between browsers. No size limits, no uploads, no servers
          storing your data — just a fast, private peer-to-peer connection.
        </p>
      </div>

      {mode === "choose" ? (
        <Card className="w-full">
          <CardContent className="flex flex-col gap-3 p-6">
            <Button
              size="lg"
              className="h-14 w-full text-base"
              onClick={initSender}
            >
              Send Files
              <ArrowRight className="size-5" />
            </Button>

            <div className="flex items-center gap-3 py-1">
              <div className="h-px flex-1 bg-border" />
              <span className="text-xs uppercase tracking-wide text-muted-foreground">or</span>
              <div className="h-px flex-1 bg-border" />
            </div>

            <Button
              size="lg"
              variant="outline"
              className="h-14 w-full text-base"
              onClick={handleReceiveClick}
            >
              <ArrowDownToLine className="size-5" />
              Receive Files
            </Button>

            {/* Feature highlights */}
            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
              <Feature
                icon={<Wifi className="size-4" />}
                title="Direct P2P"
                desc="Files stream browser-to-browser over WebRTC."
              />
              <Feature
                icon={<Zap className="size-4" />}
                title="No size limits"
                desc="Send gigabytes. Chunked & resumable."
              />
              <Feature
                icon={<ShieldCheck className="size-4" />}
                title="Private"
                desc="Encrypted transport. Sender approves every peer."
              />
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card className="w-full">
          <CardContent className="flex flex-col gap-4 p-6">
            <div className="flex items-center gap-3">
              <div className="flex size-10 items-center justify-center rounded-full bg-primary/10 text-primary">
                <ArrowDownToLine className="size-5" />
              </div>
              <div>
                <h2 className="text-base font-semibold">Receive files</h2>
                <p className="text-xs text-muted-foreground">
                  Enter the sender’s Transfer ID to connect.
                </p>
              </div>
            </div>
            <div>
              <label htmlFor="transfer-id" className="mb-1.5 block text-sm font-medium">
                Transfer ID
              </label>
              <Input
                id="transfer-id"
                inputMode="numeric"
                autoFocus
                autoComplete="off"
                placeholder="482-731-905"
                value={transferId}
                onChange={(e) => setTransferId(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleReceive()
                }}
                className="text-center text-lg tracking-widest"
              />
              <p className="mt-1.5 text-xs text-muted-foreground">
                Ask the sender for their 9-digit code — they can find it on the
                “Send files” screen.
              </p>
            </div>
            <Button
              size="lg"
              className="h-12 w-full"
              onClick={handleReceive}
              disabled={!transferId.trim() || joining}
            >
              {joining ? (
                <>
                  <Loader2 className="size-4 animate-spin" />
                  Connecting…
                </>
              ) : (
                <>
                  Connect
                  <ArrowRight className="size-4" />
                </>
              )}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setMode("choose")}
              className="mx-auto"
            >
              <ArrowLeft className="size-4" />
              Back
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function Feature({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="flex flex-col gap-1 rounded-lg border border-border bg-muted/30 p-3">
      <div className="flex items-center gap-1.5 text-primary">
        {icon}
        <span className="text-xs font-semibold">{title}</span>
      </div>
      <p className="text-xs text-muted-foreground">{desc}</p>
    </div>
  )
}

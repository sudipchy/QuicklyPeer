"use client"

import { Check, X, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useTransferStore } from "@/lib/store"
import { formatBytes } from "@/lib/transfer-utils"
import { AutoSaveToggle } from "./AutoSaveToggle"

/**
 * The sender started a transfer — the receiver must explicitly ACCEPT before
 * any file data flows. Shows the incoming file list, total size, and the
 * auto-save preference.
 */
export function ReceiverConfirmScreen() {
  const files = useTransferStore((s) => s.files)
  const acceptIncomingFiles = useTransferStore((s) => s.acceptIncomingFiles)
  const declineIncomingFiles = useTransferStore((s) => s.declineIncomingFiles)

  const totalSize = files.reduce((acc, f) => acc + f.meta.filesize, 0)

  return (
    <div className="mx-auto flex w-full max-w-xl flex-col gap-6 py-6">
      <Card className="border-primary/40 shadow-sm">
        <CardHeader className="items-center pb-2 text-center">
          <CardTitle className="text-lg">Incoming file transfer</CardTitle>
          <p className="text-sm text-muted-foreground">
            The sender wants to send you{" "}
            <span className="font-semibold text-foreground">
              {files.length} {files.length === 1 ? "file" : "files"}
            </span>{" "}
            ({formatBytes(totalSize)}). Accept to start receiving.
          </p>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <ul className="max-h-60 space-y-1.5 overflow-y-auto pr-1">
            {files.map((f) => (
              <li
                key={f.meta.id}
                className="flex items-center gap-3 rounded-md bg-muted px-3 py-2 text-sm"
              >
                <FileText className="size-4 shrink-0 text-primary" />
                <span className="min-w-0 flex-1 truncate">{f.meta.filename}</span>
                <span className="shrink-0 text-xs text-muted-foreground">
                  {formatBytes(f.meta.filesize)}
                </span>
              </li>
            ))}
          </ul>

          <AutoSaveToggle />

          <div className="flex items-center justify-end gap-2 pt-1">
            <Button variant="outline" onClick={declineIncomingFiles}>
              <X className="size-4" />
              Decline
            </Button>
            <Button size="lg" onClick={acceptIncomingFiles}>
              <Check className="size-4" />
              Accept transfer
            </Button>
          </div>
        </CardContent>
      </Card>

      <Badge variant="secondary" className="mx-auto">
        Nothing is saved until you accept
      </Badge>
    </div>
  )
}

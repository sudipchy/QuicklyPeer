"use client"

import { useEffect } from "react"
import { Link2, Loader2, ArrowLeft, Hourglass } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useTransferStore } from "@/lib/store"
import { AutoSaveToggle } from "./AutoSaveToggle"

/**
 * Receiver has been approved by the sender and the WebRTC DataChannel is
 * open. Nothing flows yet — the receiver now waits for the sender to offer
 * the files (which the receiver must explicitly accept).
 */
export function ReceiverReadyScreen() {
  const peerConnected = useTransferStore((s) => s.peerConnected)
  const cancel = useTransferStore((s) => s.cancel)

  // Clean up blob URLs on unmount to avoid leaks.
  const files = useTransferStore((s) => s.files)
  useEffect(() => {
    return () => {
      files.forEach((f) => {
        if (f.blobUrl) URL.revokeObjectURL(f.blobUrl)
      })
    }
  }, [])

  return (
    <div className="mx-auto flex w-full max-w-xl flex-col gap-6 py-6">
      <Card>
        <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
          <div className="relative flex size-16 items-center justify-center">
            <span className="absolute inline-flex size-16 animate-ping rounded-full bg-emerald-500/20" />
            <span className="relative flex size-12 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400">
              <Link2 className="size-6" />
            </span>
          </div>
          <div>
            <h2 className="text-xl font-bold">Connected to sender</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {peerConnected
                ? "Waiting for the sender to send files. You will be asked to accept them first."
                : "Establishing peer connection…"}
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            {peerConnected ? (
              <>
                <span className="size-1.5 animate-pulse rounded-full bg-emerald-500" />
                Direct peer-to-peer channel open
              </>
            ) : (
              <>
                <Loader2 className="size-3 animate-spin" />
                Negotiating WebRTC…
              </>
            )}
          </div>
        </CardContent>
      </Card>

      <AutoSaveToggle />

      <Button variant="ghost" size="sm" className="mx-auto" onClick={() => cancel("Receiver left")}>
        <ArrowLeft className="size-4" />
        Disconnect and go home
      </Button>
    </div>
  )
}

/**
 * Small hourglass badge reused by other waiting screens.
 */
export function WaitingBadge() {
  return (
    <Badge variant="secondary" className="gap-1">
      <Hourglass className="size-3" />
      Waiting
    </Badge>
  )
}

"use client"

import { useEffect } from "react"
import { Loader2, Hourglass, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useTransferStore } from "@/lib/store"
import { formatBytes } from "@/lib/transfer-utils"

/**
 * Receiver is connected to the signaling server and has requested to join.
 * Waiting for the sender to approve. Shows a preview of the files the sender
 * registered (from the join API response).
 */
export function ReceiverWaitingScreen() {
  const transferId = useTransferStore((s) => s.transferId)
  const files = useTransferStore((s) => s.files)
  const signalingConnected = useTransferStore((s) => s.signalingConnected)
  const goHome = useTransferStore((s) => s.goHome)

  // Clean up blob URLs on unmount to avoid leaks.
  useEffect(() => {
    return () => {
      files.forEach((f) => {
        if (f.blobUrl) URL.revokeObjectURL(f.blobUrl)
      })
    }
  }, [])

  const totalSize = files.reduce((acc, f) => acc + f.meta.filesize, 0)

  return (
    <div className="mx-auto flex w-full max-w-xl flex-col gap-6 py-6">
      <Card>
        <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
          <div className="relative flex size-16 items-center justify-center">
            <span className="absolute inline-flex size-16 animate-ping rounded-full bg-primary/20" />
            <span className="relative flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Hourglass className="size-6" />
            </span>
          </div>
          <div>
            <h2 className="text-xl font-bold">Waiting for sender to approve</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Transfer ID <span className="font-mono font-semibold">{transferId}</span>
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            {signalingConnected ? (
              <>
                <span className="size-1.5 animate-pulse rounded-full bg-emerald-500" />
                Connected to signaling server
              </>
            ) : (
              <>
                <Loader2 className="size-3 animate-spin" />
                Connecting…
              </>
            )}
          </div>
        </CardContent>
      </Card>

      {files.length > 0 && (
        <Card>
          <CardContent className="p-4">
            <div className="mb-2 flex items-center justify-between px-1">
              <span className="text-sm font-medium">Files waiting</span>
              <span className="text-xs text-muted-foreground">
                {files.length} · {formatBytes(totalSize)}
              </span>
            </div>
            <ul className="max-h-60 space-y-1.5 overflow-y-auto pr-1">
              {files.map((f) => (
                <li
                  key={f.meta.id}
                  className="truncate rounded-md bg-muted px-3 py-2 text-sm"
                >
                  {f.meta.filename}
                  <span className="ml-2 text-xs text-muted-foreground">
                    {formatBytes(f.meta.filesize)}
                  </span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      <Button variant="ghost" size="sm" className="mx-auto" onClick={goHome}>
        <ArrowLeft className="size-4" />
        Cancel and go home
      </Button>
    </div>
  )
}

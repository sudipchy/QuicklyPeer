"use client"

import { useState } from "react"
import { CheckCircle2, Play, X, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useTransferStore } from "@/lib/store"
import { formatBytes } from "@/lib/transfer-utils"
import { FileDropzone } from "./FileDropzone"

/**
 * Shown after the receiver is approved and the WebRTC DataChannel is open.
 * The sender reviews/edits the file list and sends the transfer request —
 * the receiver must accept it before files start flowing.
 */
export function SenderConnectedScreen() {
  const files = useTransferStore((s) => s.files)
  const notice = useTransferStore((s) => s.notice)
  const registerFiles = useTransferStore((s) => s.registerFiles)
  const startTransfer = useTransferStore((s) => s.startTransfer)
  const cancel = useTransferStore((s) => s.cancel)
  const peerConnected = useTransferStore((s) => s.peerConnected)
  const transferId = useTransferStore((s) => s.transferId)

  // Seed the dropzone with File objects we still hold (best-effort: the store
  // keeps raw File refs in _rawFiles, but they're not exposed to the UI to
  // avoid stale handles. We let the user re-pick if the list is empty.)
  const [selectedFiles, setSelectedFiles] = useState<File[]>([])

  const handleFilesChange = (next: File[]) => {
    setSelectedFiles(next)
    if (next.length > 0) registerFiles(next)
  }

  const totalSize = files.reduce((acc, f) => acc + f.meta.filesize, 0)

  return (
    <div className="mx-auto flex w-full max-w-2xl flex-col gap-6 py-6">
      <div className="flex items-center gap-3 rounded-xl border border-emerald-200 bg-emerald-50 p-4 dark:border-emerald-900 dark:bg-emerald-950/40">
        <CheckCircle2 className="size-6 text-emerald-600 dark:text-emerald-400" />
        <div>
          <div className="text-sm font-semibold text-emerald-800 dark:text-emerald-300">
            {peerConnected ? "Connected to receiver" : "Establishing peer connection…"}
          </div>
          <div className="text-xs text-emerald-700/80 dark:text-emerald-400/80">
            {peerConnected
              ? "Your browsers established a direct peer-to-peer link."
              : "Negotiating WebRTC — this takes a moment."}
          </div>
        </div>
      </div>

      {notice && (
        <div className="flex items-start gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4 dark:border-amber-900 dark:bg-amber-950/40">
          <Info className="mt-0.5 size-5 shrink-0 text-amber-600 dark:text-amber-400" />
          <p className="text-sm text-amber-800 dark:text-amber-300">{notice}</p>
        </div>
      )}

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0">
          <CardTitle className="text-base">Files to send</CardTitle>
          <Badge variant="secondary">
            {files.length} · {formatBytes(totalSize)}
          </Badge>
        </CardHeader>
        <CardContent>
          <FileDropzone
            files={selectedFiles}
            onFilesChange={handleFilesChange}
          />
        </CardContent>
      </Card>

      <div className="flex items-center justify-between gap-3">
        <Button variant="ghost" onClick={() => cancel("Sender cancelled")}>
          <X className="size-4" />
          Cancel
        </Button>
        <div className="flex flex-col items-end gap-1">
          <Button size="lg" onClick={startTransfer} disabled={files.length === 0 || !peerConnected}>
            <Play className="size-4" />
            Send Files
          </Button>
          <p className="text-xs text-muted-foreground">
            {transferId ? (
              <>
                Transfer ID <span className="font-mono font-semibold text-foreground">{transferId}</span> · receiver must accept
              </>
            ) : (
              "Receiver must accept before files flow"
            )}
          </p>
        </div>
      </div>
    </div>
  )
}

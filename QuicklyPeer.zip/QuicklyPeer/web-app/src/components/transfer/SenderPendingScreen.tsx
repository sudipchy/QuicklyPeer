"use client"

import { Check, X, Smartphone, Monitor, Tablet } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useTransferStore } from "@/lib/store"
import type { DeviceInfo } from "@/lib/types"

/**
 * Shown when one or more receivers have requested to join. The sender must
 * approve before the WebRTC connection is established.
 */
export function SenderPendingScreen() {
  const pendingReceivers = useTransferStore((s) => s.pendingReceivers)
  const approveReceiver = useTransferStore((s) => s.approveReceiver)
  const rejectReceiver = useTransferStore((s) => s.rejectReceiver)

  return (
    <div className="mx-auto flex w-full max-w-xl flex-col gap-6 py-6">
      <div className="text-center">
        <h2 className="text-xl font-bold">New device wants to connect</h2>
        <p className="text-sm text-muted-foreground">
          Approve to start a direct peer-to-peer connection. Only one receiver
          can connect at a time.
        </p>
      </div>

      <div className="flex flex-col gap-3">
        {pendingReceivers.map((r) => (
          <Card key={r.receiverSocketId}>
            <CardHeader>
              <CardTitle className="flex items-center justify-between text-base">
                <span className="flex items-center gap-2">
                  <DeviceIcon deviceInfo={r.deviceInfo} />
                  {r.deviceInfo.browser} on {r.deviceInfo.os}
                </span>
                <Badge variant="secondary" className="capitalize">
                  {r.deviceInfo.deviceType}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="flex items-center justify-end gap-2">
              <Button variant="outline" size="sm" onClick={() => rejectReceiver(r.receiverSocketId)}>
                <X className="size-4" />
                Reject
              </Button>
              <Button size="sm" onClick={() => approveReceiver(r.receiverSocketId)}>
                <Check className="size-4" />
                Accept
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

function DeviceIcon({ deviceInfo }: { deviceInfo: DeviceInfo }) {
  if (deviceInfo.deviceType === "mobile") return <Smartphone className="size-4" />
  if (deviceInfo.deviceType === "tablet") return <Tablet className="size-4" />
  return <Monitor className="size-4" />
}

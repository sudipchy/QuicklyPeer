"use client"

import { Send, Loader2, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { useTransferStore } from "@/lib/store"
import { formatBytes } from "@/lib/transfer-utils"

/**
 * The sender offered the files and is now waiting for the receiver to
 * ACCEPT the transfer on their device. Streaming starts automatically the
 * moment the receiver accepts.
 */
export function SenderRequestingScreen() {
  const files = useTransferStore((s) => s.files)
  const cancel = useTransferStore((s) => s.cancel)

  const totalSize = files.reduce((acc, f) => acc + f.meta.filesize, 0)

  return (
    <div className="mx-auto flex w-full max-w-xl flex-col gap-6 py-6">
      <Card>
        <CardContent className="flex flex-col items-center gap-4 p-8 text-center">
          <div className="relative flex size-16 items-center justify-center">
            <span className="absolute inline-flex size-16 animate-ping rounded-full bg-primary/20" />
            <span className="relative flex size-12 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Send className="size-6" />
            </span>
          </div>
          <div>
            <h2 className="text-xl font-bold">Waiting for the receiver to accept</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Transfer starts automatically once they tap <strong>Accept</strong> on
              their device.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <Loader2 className="size-3 animate-spin" />
            {files.length} {files.length === 1 ? "file" : "files"} · {formatBytes(totalSize)} ready
          </div>
        </CardContent>
      </Card>

      <Button variant="ghost" size="sm" className="mx-auto" onClick={() => cancel("Transfer cancelled")}>
        <X className="size-4" />
        Cancel request
      </Button>
    </div>
  )
}

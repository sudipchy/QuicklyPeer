"use client"

import { useEffect, useMemo, useState } from "react"
import { Clock, Loader2, Radio, Copy, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useTransferStore } from "@/lib/store"
import { ShareQRCode } from "./ShareQRCode"
import { ShareButtons } from "./ShareButtons"
import { FileDropzone } from "./FileDropzone"
import { formatBytes } from "@/lib/transfer-utils"

/**
 * Sender waiting screen: shows the Transfer ID, QR code, share buttons, and a
 * file picker. The sender can add files any time before the transfer starts.
 */
export function SenderWaitingScreen() {
  const transferId = useTransferStore((s) => s.transferId)
  const shareUrl = useTransferStore((s) => s.shareUrl)
  const signalingConnected = useTransferStore((s) => s.signalingConnected)
  const registerFiles = useTransferStore((s) => s.registerFiles)
  const files = useTransferStore((s) => s.files)

  const [selectedFiles, setSelectedFiles] = useState<File[]>([])
  const [copied, setCopied] = useState(false)

  const handleCopyId = async () => {
    if (!transferId) return
    try {
      await navigator.clipboard.writeText(transferId)
    } catch {
      // Clipboard API can be blocked (e.g. insecure origins) — fall back.
      const ta = document.createElement("textarea")
      ta.value = transferId
      document.body.appendChild(ta)
      ta.select()
      document.execCommand("copy")
      ta.remove()
    }
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  // Whenever the selected files change, persist them to the server + store.
  useEffect(() => {
    if (selectedFiles.length > 0) {
      registerFiles(selectedFiles)
    }
  }, [selectedFiles, registerFiles])

  const absoluteShareUrl = useMemo(() => {
    if (!shareUrl) return ""
    if (typeof window === "undefined") return shareUrl
    return `${window.location.origin}${shareUrl}`
  }, [shareUrl])

  const totalSize = files.reduce((acc, f) => acc + f.meta.filesize, 0)

  return (
    <div className="mx-auto flex w-full max-w-2xl flex-col gap-6 py-6">
      {/* Status banner */}
      <div className="flex items-center justify-between rounded-xl border border-border bg-card p-4">
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-full bg-primary/10 text-primary">
            <Radio className="size-5" />
          </div>
          <div>
            <div className="text-sm font-semibold">
              {signalingConnected ? "Waiting for a receiver…" : "Connecting…"}
            </div>
            <div className="text-xs text-muted-foreground">
              Keep this tab open. Share the code or link below.
            </div>
          </div>
        </div>
        <Badge variant={signalingConnected ? "default" : "secondary"} className="gap-1">
          {signalingConnected ? (
            <>
              <span className="size-1.5 animate-pulse rounded-full bg-emerald-500" />
              Online
            </>
          ) : (
            <>
              <Loader2 className="size-3 animate-spin" />
              Connecting
            </>
          )}
        </Badge>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Transfer ID + QR */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Transfer ID</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center gap-4">
            <button
              type="button"
              onClick={handleCopyId}
              title="Copy Transfer ID"
              aria-label="Copy Transfer ID"
              className="group flex items-center gap-3 rounded-lg bg-muted px-6 py-3 font-mono text-2xl font-bold tracking-[0.3em] transition-colors hover:bg-muted/70"
            >
              {transferId}
              {copied ? (
                <Check className="size-4 shrink-0 text-emerald-600" />
              ) : (
                <Copy className="size-4 shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
              )}
            </button>
            <p className="-mt-2 text-xs text-muted-foreground">
              The receiver types this code under <span className="font-medium">Receive files</span>
            </p>
            {absoluteShareUrl && (
              <ShareQRCode value={absoluteShareUrl} size={180} />
            )}
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <Clock className="size-3" />
              Session expires in 30 minutes
            </div>
          </CardContent>
        </Card>

        {/* Share + files */}
        <div className="flex flex-col gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Share</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              {absoluteShareUrl && (
                <div className="break-all rounded-md bg-muted px-3 py-2 text-xs text-muted-foreground">
                  {absoluteShareUrl}
                </div>
              )}
              <ShareButtons url={absoluteShareUrl} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0">
              <CardTitle className="text-base">Files to send</CardTitle>
              {files.length > 0 && (
                <Badge variant="secondary">
                  {files.length} · {formatBytes(totalSize)}
                </Badge>
              )}
            </CardHeader>
            <CardContent>
              <FileDropzone files={selectedFiles} onFilesChange={setSelectedFiles} />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

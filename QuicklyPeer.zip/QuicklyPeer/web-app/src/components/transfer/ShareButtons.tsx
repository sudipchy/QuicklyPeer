"use client"

import { useState } from "react"
import { Check, Copy, Share2, MessageCircle, Mail, Send } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"

interface ShareButtonsProps {
  /** The text/URL to share. */
  url: string
  /** Optional message body for social shares. */
  message?: string
  className?: string
}

/**
 * Row of share actions: copy link, native Web Share, WhatsApp, Telegram, Email.
 * Only the *link* is shared — never the file bytes.
 */
export function ShareButtons({ url, message, className }: ShareButtonsProps) {
  const [copied, setCopied] = useState(false)
  const { toast } = useToast()

  const shareText = message ?? `Someone wants to send you files via QuicklyPeer. Open this link to connect:`
  const fullText = `${shareText}\n${url}`

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(url)
      setCopied(true)
      toast({ title: "Link copied", description: "The transfer link is on your clipboard." })
      setTimeout(() => setCopied(false), 2000)
    } catch {
      toast({ title: "Could not copy", description: "Copy this link manually.", variant: "destructive" })
    }
  }

  const handleNativeShare = async () => {
    if (typeof navigator !== "undefined" && navigator.share) {
      try {
        await navigator.share({ title: "QuicklyPeer transfer", text: shareText, url })
      } catch {
        // user cancelled — no-op
      }
    } else {
      handleCopy()
    }
  }

  const encoded = encodeURIComponent(fullText)

  return (
    <div className={"flex flex-wrap items-center gap-2 " + (className ?? "")}>
      <Button onClick={handleCopy} variant="outline" size="sm">
        {copied ? <Check className="size-4 text-emerald-500" /> : <Copy className="size-4" />}
        {copied ? "Copied" : "Copy Link"}
      </Button>
      <Button onClick={handleNativeShare} variant="outline" size="sm">
        <Share2 className="size-4" />
        Share
      </Button>
      <Button asChild variant="outline" size="sm">
        <a
          href={`https://wa.me/?text=${encoded}`}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Share on WhatsApp"
        >
          <MessageCircle className="size-4" />
          WhatsApp
        </a>
      </Button>
      <Button asChild variant="outline" size="sm">
        <a
          href={`https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(shareText)}`}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Share on Telegram"
        >
          <Send className="size-4" />
          Telegram
        </a>
      </Button>
      <Button asChild variant="outline" size="sm">
        <a
          href={`mailto:?subject=${encodeURIComponent("QuicklyPeer file transfer")}&body=${encoded}`}
          aria-label="Share by Email"
        >
          <Mail className="size-4" />
          Email
        </a>
      </Button>
    </div>
  )
}

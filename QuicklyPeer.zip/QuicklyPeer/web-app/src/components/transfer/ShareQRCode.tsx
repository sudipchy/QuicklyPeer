"use client"

import { QRCodeCanvas } from "qrcode.react"

interface ShareQRCodeProps {
  /** Full absolute URL to encode in the QR code. */
  value: string
  /** Pixel size of the canvas. */
  size?: number
  className?: string
}

/**
 * Renders a QR code that points to the share URL so receivers can scan it
 * with their phone camera and open the transfer join page.
 */
export function ShareQRCode({ value, size = 192, className }: ShareQRCodeProps) {
  return (
    <div
      className={
        "rounded-xl bg-white p-3 shadow-sm ring-1 ring-border " + (className ?? "")
      }
    >
      <QRCodeCanvas
        value={value}
        size={size}
        level="M"
        marginSize={1}
        aria-label="QR code for the transfer link"
      />
    </div>
  )
}

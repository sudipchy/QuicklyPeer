"use client"

import { CheckCircle2, Download, Home, FileText, HardDrive } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useTransferStore } from "@/lib/store"
import { formatBytes } from "@/lib/transfer-utils"

/**
 * Transfer-complete view. For the receiver, files were auto-saved to the
 * Downloads folder (when auto-save is on) and can be re-saved manually.
 * For the sender, confirms success.
 */
export function TransferDoneScreen() {
  const role = useTransferStore((s) => s.role)
  const files = useTransferStore((s) => s.files)
  const autoSave = useTransferStore((s) => s.autoSave)
  const goHome = useTransferStore((s) => s.goHome)

  const savedCount = files.filter((f) => f.savedToDisk).length

  return (
    <div className="mx-auto flex w-full max-w-2xl flex-col gap-6 py-6">
      <Card>
        <CardContent className="flex flex-col items-center gap-3 p-8 text-center">
          <div className="flex size-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400">
            <CheckCircle2 className="size-9" />
          </div>
          <h2 className="text-2xl font-bold">Transfer complete</h2>
          <p className="max-w-sm text-sm text-muted-foreground">
            {role === "sender"
              ? "All files were delivered to the receiver over a direct peer-to-peer connection."
              : autoSave
                ? `All files were received and saved to your Downloads folder${savedCount ? ` (${savedCount} file${savedCount === 1 ? "" : "s"})` : ""}.`
                : "All files were received. Save them to disk below."}
          </p>
          <div className="flex gap-2 pt-2">
            <Button onClick={goHome}>
              <Home className="size-4" />
              New Transfer
            </Button>
            {role === "receiver" && (
              <DownloadAllButton files={files} />
            )}
          </div>
        </CardContent>
      </Card>

      {role === "receiver" && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base">Received files</CardTitle>
            {autoSave && savedCount > 0 && (
              <Badge variant="secondary" className="gap-1 text-emerald-700 dark:text-emerald-400">
                <HardDrive className="size-3" />
                {savedCount}/{files.length} saved to disk
              </Badge>
            )}
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {files.map((f) => (
                <li
                  key={f.meta.id}
                  className="flex items-center gap-3 rounded-lg border border-border bg-card p-3"
                >
                  <div className="flex size-9 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
                    <FileText className="size-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium">{f.meta.filename}</div>
                    <div className="text-xs text-muted-foreground">
                      {formatBytes(f.meta.filesize)}
                      {f.savedToDisk && " · saved to Downloads folder"}
                    </div>
                  </div>
                  {f.blobUrl && (
                    <Button asChild size="sm" variant="outline">
                      <a href={f.blobUrl} download={f.meta.filename}>
                        <Download className="size-4" />
                        {f.savedToDisk ? "Save again" : "Save to disk"}
                      </a>
                    </Button>
                  )}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {role === "sender" && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Sent files</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {files.map((f) => (
                <li
                  key={f.meta.id}
                  className="flex items-center gap-3 rounded-lg border border-border bg-card p-3"
                >
                  <div className="flex size-9 shrink-0 items-center justify-center rounded-md bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400">
                    <CheckCircle2 className="size-4" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-sm font-medium">{f.meta.filename}</div>
                    <div className="text-xs text-muted-foreground">
                      {formatBytes(f.meta.filesize)}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

function DownloadAllButton({ files }: { files: ReturnType<typeof useTransferStore.getState>["files"] }) {
  const downloadAll = () => {
    files.forEach((f) => {
      if (f.blobUrl) {
        const a = document.createElement("a")
        a.href = f.blobUrl
        a.download = f.meta.filename
        document.body.appendChild(a)
        a.click()
        a.remove()
      }
    })
  }
  return (
    <Button variant="outline" onClick={downloadAll} disabled={!files.some((f) => f.blobUrl)}>
      <Download className="size-4" />
      Save all to disk
    </Button>
  )
}

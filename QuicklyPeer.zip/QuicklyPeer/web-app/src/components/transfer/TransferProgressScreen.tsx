"use client"

import { FileText, CheckCircle2, Loader2, Pause, Play, X, Download, HardDrive } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { useTransferStore } from "@/lib/store"
import { formatBytes, formatSpeed, formatDuration } from "@/lib/transfer-utils"
import { AutoSaveToggle } from "./AutoSaveToggle"

/**
 * Active transfer view — shared by sender and receiver. Shows per-file
 * progress, overall speed, ETA, and pause/resume/cancel controls.
 */
export function TransferProgressScreen() {
  const role = useTransferStore((s) => s.role)
  const files = useTransferStore((s) => s.files)
  const speed = useTransferStore((s) => s.speed)
  const paused = useTransferStore((s) => s.paused)
  const pause = useTransferStore((s) => s.pause)
  const resume = useTransferStore((s) => s.resume)
  const cancel = useTransferStore((s) => s.cancel)

  const totalBytes = files.reduce((acc, f) => acc + f.total, 0)
  const transferredBytes = files.reduce((acc, f) => acc + f.transferred, 0)
  const overallPct = totalBytes > 0 ? Math.min(100, (transferredBytes / totalBytes) * 100) : 0
  const eta = speed > 0 ? (totalBytes - transferredBytes) / speed : Infinity

  const activeFile = files.find((f) => f.status === "transferring")
  const doneCount = files.filter((f) => f.status === "done").length

  return (
    <div className="mx-auto flex w-full max-w-2xl flex-col gap-6 py-6">
      {/* Overall progress */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between text-base">
            <span className="flex items-center gap-2">
              {role === "sender" ? "Sending files" : "Receiving files"}
              {paused && <Badge variant="secondary">Paused</Badge>}
            </span>
            <span className="text-sm font-normal text-muted-foreground">
              {doneCount}/{files.length} done
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="flex items-end justify-between">
            <div>
              <div className="text-3xl font-bold tabular-nums">
                {overallPct.toFixed(0)}%
              </div>
              <div className="text-xs text-muted-foreground">
                {formatBytes(transferredBytes)} / {formatBytes(totalBytes)}
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm font-semibold tabular-nums">
                {formatSpeed(speed)}
              </div>
              <div className="text-xs text-muted-foreground">
                {Number.isFinite(eta) ? `${formatDuration(eta)} left` : "calculating…"}
              </div>
            </div>
          </div>
          <Progress value={overallPct} className="h-2.5" />

          {role === "receiver" && <AutoSaveToggle className="mb-1" />}

          {activeFile && (
            <div className="rounded-md bg-muted px-3 py-2 text-xs text-muted-foreground">
              Now: <span className="font-medium text-foreground">{activeFile.meta.filename}</span>
            </div>
          )}

          <div className="flex items-center justify-end gap-2">
            <Button variant="outline" size="sm" onClick={() => cancel("Transfer cancelled")}>
              <X className="size-4" />
              Cancel
            </Button>
            {paused ? (
              <Button size="sm" onClick={resume}>
                <Play className="size-4" />
                Resume
              </Button>
            ) : (
              <Button size="sm" variant="outline" onClick={pause}>
                <Pause className="size-4" />
                Pause
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Per-file list */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Files</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="max-h-80 space-y-2 overflow-y-auto pr-1">
            {files.map((f) => {
              const pct = f.total > 0 ? Math.min(100, (f.transferred / f.total) * 100) : 0
              return (
                <li
                  key={f.meta.id}
                  className="flex flex-col gap-2 rounded-lg border border-border bg-card p-3"
                >
                  <div className="flex items-center gap-3">
                    <div className="flex size-9 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
                      <FileText className="size-4" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium">{f.meta.filename}</div>
                      <div className="text-xs text-muted-foreground">
                        {formatBytes(f.transferred)} / {formatBytes(f.total)}
                      </div>
                    </div>
                    {role === "receiver" && f.savedToDisk ? (
                      <Badge variant="secondary" className="gap-1 text-emerald-700 dark:text-emerald-400">
                        <HardDrive className="size-3" />
                        Saved
                      </Badge>
                    ) : (
                      <FileStatus status={f.status} />
                    )}
                  </div>
                  <Progress value={pct} className="h-1.5" />
                  {role === "receiver" && f.status === "done" && f.blobUrl && !f.savedToDisk && (
                    <Button asChild size="sm" variant="outline" className="self-start">
                      <a href={f.blobUrl} download={f.meta.filename}>
                        <Download className="size-4" />
                        Save to disk
                      </a>
                    </Button>
                  )}
                </li>
              )
            })}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

function FileStatus({ status }: { status: "pending" | "transferring" | "done" | "error" }) {
  if (status === "done")
    return <CheckCircle2 className="size-5 text-emerald-500" aria-label="Done" />
  if (status === "transferring")
    return <Loader2 className="size-5 animate-spin text-primary" aria-label="Transferring" />
  if (status === "error")
    return <X className="size-5 text-destructive" aria-label="Error" />
  return <span className="text-xs text-muted-foreground">Queued</span>
}

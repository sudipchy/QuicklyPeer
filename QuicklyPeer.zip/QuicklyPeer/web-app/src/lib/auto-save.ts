/**
 * QuicklyPeer — auto-save helper
 *
 * A web page cannot write to an arbitrary disk path silently, but it CAN
 * save a file to the browser's default Downloads folder through a
 * programmatic anchor click ("Save to disk"). This module queues those saves
 * so files that finish back-to-back are written one at a time — browsers
 * block or drop parallel programmatic downloads.
 */

let chain: Promise<void> = Promise.resolve()

function download(blobUrl: string, filename: string) {
  if (typeof document === 'undefined') return
  const a = document.createElement('a')
  a.href = blobUrl
  // Keep the original name but strip anything path-like for safety.
  a.download = filename.replace(/[/\\]+/g, '_')
  a.style.display = 'none'
  document.body.appendChild(a)
  a.click()
  a.remove()
}

function delay(ms: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, ms))
}

/**
 * Queue a file for saving to the Downloads folder. Sequential by design:
 * each save waits for the previous one (plus a small gap) to keep browsers
 * from suppressing repeated automatic downloads.
 */
export function saveFileToDisk(blobUrl: string, filename: string) {
  chain = chain
    .then(() => {
      download(blobUrl, filename)
      return delay(350)
    })
    .catch(() => {
      // Never let one failed save break the queue.
    })
}

/**
 * QuicklyPeer — IndexedDB persistence for transfer resume metadata
 *
 * Stores per-file received-chunk offsets so that an interrupted transfer can
 * resume instead of restarting from zero. We store a lightweight record per
 * (sessionToken, fileId) rather than the raw chunks (memory is for chunks).
 */

const DB_NAME = 'quicklypeer'
const DB_VERSION = 1
const STORE = 'transfer-meta'

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION)
    req.onupgradeneeded = () => {
      const db = req.result
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: 'key' })
      }
    }
    req.onsuccess = () => resolve(req.result)
    req.onerror = () => reject(req.error)
  })
}

export interface TransferMetaRecord {
  key: string // `${sessionToken}:${fileId}`
  sessionToken: string
  fileId: string
  filename: string
  filesize: number
  mimeType: string
  checksum?: string
  receivedOffsets: number[] // byte offsets of received chunks
  lastUpdated: number
}

function key(sessionToken: string, fileId: string) {
  return `${sessionToken}:${fileId}`
}

export async function saveTransferMeta(record: TransferMetaRecord) {
  try {
    const db = await openDb()
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite')
      tx.objectStore(STORE).put(record)
      tx.oncomplete = () => resolve()
      tx.onerror = () => reject(tx.error)
    })
    db.close()
  } catch {
    // IndexedDB failures should never break the transfer.
  }
}

export async function getTransferMeta(
  sessionToken: string,
  fileId: string
): Promise<TransferMetaRecord | null> {
  try {
    const db = await openDb()
    const result = await new Promise<TransferMetaRecord | null>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readonly')
      const req = tx.objectStore(STORE).get(key(sessionToken, fileId))
      req.onsuccess = () => resolve(req.result ?? null)
      req.onerror = () => reject(req.error)
    })
    db.close()
    return result
  } catch {
    return null
  }
}

export async function clearTransferMeta(sessionToken: string) {
  try {
    const db = await openDb()
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite')
      const store = tx.objectStore(STORE)
      const req = store.openCursor()
      req.onsuccess = () => {
        const cursor = req.result
        if (cursor) {
          const rec = cursor.value as TransferMetaRecord
          if (rec.sessionToken === sessionToken) {
            cursor.delete()
          }
          cursor.continue()
        }
      }
      tx.oncomplete = () => resolve()
      tx.onerror = () => reject(tx.error)
    })
    db.close()
  } catch {
    // ignore
  }
}

/**
 * QuicklyPeer — DataChannel wire protocol
 *
 * All messages are sent as JSON control messages, EXCEPT chunk payloads which
 * are sent as raw binary ArrayBuffer frames for zero-copy efficiency.
 *
 * Frame layout:
 *   - Control message:  UTF-8 JSON string  (text frame)
 *   - Chunk payload:    ArrayBuffer        (binary frame), prefixed with a
 *                       small JSON header via a 1-byte tag is NOT used —
 *                       instead, chunk ordering is conveyed by a preceding
 *                       `chunk` control message carrying the offset.
 *
 * To keep the protocol simple and robust we use the following approach:
 *   1. Sender sends `file-start` (JSON) with file metadata + chunkSize.
 *   2. For every chunk, sender sends `chunk` (JSON) {fileId, offset, size}
 *      immediately followed by a binary frame of exactly `size` bytes.
 *   3. Receiver ACKs ranges with `chunk-ack` {fileId, offset, size}.
 *   4. Sender pauses when bufferedAmount > HIGH_WATERMARK and resumes when it
 *      drops below LOW_WATERMARK (DataChannel backpressure).
 *   5. On completion sender sends `file-end` {fileId, checksum}.
 *   6. Receiver verifies checksum and sends `file-complete` {fileId, ok}.
 *   7. `transfer-end` signals all files done.
 *   8. `pause` / `resume` / `cancel` control the transfer.
 */

export type ControlMessage =
  | { type: 'manifest'; files: Array<{ id: string; filename: string; filesize: number; mimeType: string; checksum?: string }> }
  | { type: 'select-files'; fileIds: string[] }
  // Sender asks the receiver for explicit consent before streaming begins.
  | { type: 'transfer-request'; files: Array<{ id: string; filename: string; filesize: number; mimeType: string; checksum?: string }> }
  // Receiver consents (transfer starts) or declines (sender stays connected).
  | { type: 'transfer-accept' }
  | { type: 'transfer-decline'; reason?: string }
  | { type: 'file-start'; fileId: string; filename: string; filesize: number; mimeType: string; checksum?: string; chunkSize: number }
  | { type: 'chunk'; fileId: string; offset: number; size: number }
  | { type: 'chunk-ack'; fileId: string; offset: number; size: number }
  | { type: 'file-end'; fileId: string; checksum?: string }
  | { type: 'file-complete'; fileId: string; ok: boolean }
  | { type: 'transfer-end' }
  | { type: 'pause' }
  | { type: 'resume' }
  | { type: 'cancel'; reason?: string }
  | { type: 'hello'; role: 'sender' | 'receiver' }

export function encodeControl(msg: ControlMessage): string {
  return JSON.stringify(msg)
}

export function decodeControl(data: string): ControlMessage | null {
  try {
    return JSON.parse(data) as ControlMessage
  } catch {
    return null
  }
}

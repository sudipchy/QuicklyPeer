/**
 * QuicklyPeer — Server-side helpers
 *
 * Pure utilities for generating IDs / tokens and formatting.
 */

import { randomBytes } from 'crypto'

/**
 * Human-friendly transfer ID, e.g. "482-731-905".
 * 9 digits split into 3 groups. ~10^9 entropy is plenty for finding a session
 * (it is NOT the only security mechanism — the session token is the real guard).
 */
export function generateTransferId(): string {
  const digits = () => String(Math.floor(100 + Math.random() * 900))
  return `${digits()}-${digits()}-${digits()}`
}

/**
 * Cryptographically-random session token that protects the session.
 * This is the secret that authorizes joining — never rely on the human ID alone.
 */
export function generateSessionToken(): string {
  return randomBytes(32).toString('hex')
}

/** Default session lifetime: 30 minutes. */
export const SESSION_TTL_MS = 30 * 60 * 1000

export function defaultExpiry(now = Date.now()): Date {
  return new Date(now + SESSION_TTL_MS)
}

export function isExpired(expiresAt: Date | string): boolean {
  const d = typeof expiresAt === 'string' ? new Date(expiresAt) : expiresAt
  return d.getTime() <= Date.now()
}

// --- client-safe formatting (duplicated client-side to avoid pulling node) ---

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return '0 B'
  if (bytes === 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']
  const i = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)))
  const value = bytes / Math.pow(1024, i)
  return `${value.toFixed(i === 0 ? 0 : value >= 100 ? 0 : 1)} ${units[i]}`
}

export function formatSpeed(bytesPerSecond: number): string {
  return `${formatBytes(bytesPerSecond)}/s`
}

export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '--'
  if (seconds < 1) return '< 1s'
  const s = Math.round(seconds)
  if (s < 60) return `${s}s`
  const m = Math.floor(s / 60)
  const rem = s % 60
  if (m < 60) return `${m}m ${rem}s`
  const h = Math.floor(m / 60)
  return `${h}h ${m % 60}m`
}

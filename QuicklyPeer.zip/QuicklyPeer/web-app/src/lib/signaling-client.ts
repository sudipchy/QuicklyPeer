/**
 * QuicklyPeer — Signaling client
 *
 * Thin wrapper around socket.io-client that talks to the signaling
 * mini-service on port 3003 (via the Caddy gateway using XTransformPort).
 *
 * Exposes typed events for the React layer to subscribe to.
 */

import { io, Socket } from 'socket.io-client'
import type { DeviceInfo } from './types'

export interface PendingReceiver {
  receiverSocketId: string
  deviceInfo: DeviceInfo
}

export type SignalingEvent =
  | { type: 'connected' }
  | { type: 'disconnected' }
  | { type: 'connect_error'; message: string }
  | { type: 'joined'; role: 'sender' | 'receiver'; senderSocketId?: string; receiverSocketId?: string; pendingRequests?: PendingReceiver[] }
  | { type: 'receiver-request'; receiverSocketId: string; deviceInfo: DeviceInfo }
  | { type: 'approved'; peerSocketId: string }
  | { type: 'rejected'; reason?: string }
  | { type: 'session-cancelled'; reason?: string }
  | { type: 'peer-left' }
  | { type: 'webrtc-offer'; from: string; sdp: RTCSessionDescriptionInit }
  | { type: 'webrtc-answer'; from: string; sdp: RTCSessionDescriptionInit }
  | { type: 'webrtc-ice-candidate'; from: string; candidate: RTCIceCandidateInit }
  | { type: 'error'; message: string }

type Listener = (event: SignalingEvent) => void

export class SignalingClient {
  private socket: Socket | null = null
  private listeners = new Set<Listener>()
  private sessionToken: string | null = null

  connect(sessionToken: string, role: 'sender' | 'receiver', deviceInfo: DeviceInfo) {
    this.disconnect()
    this.sessionToken = sessionToken

    // Two connection modes:
    //  1. Bare local dev (no reverse proxy): when the app itself is served
    //     from localhost, talk to the signaling server directly on port 3003.
    //  2. Behind a reverse proxy / remote preview (e.g. the Caddy gateway in
    //     the sandbox): use the relative path "/?XTransformPort=3003" so the
    //     gateway forwards the request to the signaling server.
    // An explicit NEXT_PUBLIC_SIGNALING_URL always wins as a manual override.
    const signalingUrl = process.env.NEXT_PUBLIC_SIGNALING_URL
    let target: string
    if (signalingUrl) {
      target = signalingUrl
    } else if (
      typeof window !== 'undefined' &&
      (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')
    ) {
      target = 'http://localhost:3003'
    } else {
      target = '/?XTransformPort=3003'
    }

    const socket = io(target, {
      transports: ['websocket', 'polling'],
      forceNew: true,
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      timeout: 15000,
    })
    this.socket = socket

    const emit = (e: SignalingEvent) => this.listeners.forEach((l) => l(e))

    socket.on('connect', () => {
      socket.emit('session:join', { sessionToken, role, deviceInfo })
      emit({ type: 'connected' })
    })
    socket.on('disconnect', () => emit({ type: 'disconnected' }))
    socket.on('connect_error', (err: Error) =>
      emit({ type: 'connect_error', message: err.message })
    )

    socket.on('session:joined', (payload: any) => {
      emit({
        type: 'joined',
        role: payload.role,
        senderSocketId: payload.sender?.socketId,
        receiverSocketId: payload.receiver?.socketId,
        pendingRequests: payload.pendingRequests,
      })
    })

    socket.on('receiver:request', (payload: any) =>
      emit({
        type: 'receiver-request',
        receiverSocketId: payload.receiverSocketId,
        deviceInfo: payload.deviceInfo,
      })
    )

    socket.on('session:approved', (payload: any) =>
      emit({ type: 'approved', peerSocketId: payload.senderSocketId ?? payload.receiverSocketId })
    )
    socket.on('session:rejected', (payload: any) =>
      emit({ type: 'rejected', reason: payload?.reason })
    )
    socket.on('session:cancelled', (payload: any) =>
      emit({ type: 'session-cancelled', reason: payload?.reason })
    )
    socket.on('session:peer-left', () => emit({ type: 'peer-left' }))

    socket.on('webrtc:offer', (payload: any) =>
      emit({ type: 'webrtc-offer', from: payload.from, sdp: payload.sdp })
    )
    socket.on('webrtc:answer', (payload: any) =>
      emit({ type: 'webrtc-answer', from: payload.from, sdp: payload.sdp })
    )
    socket.on('webrtc:ice-candidate', (payload: any) =>
      emit({ type: 'webrtc-ice-candidate', from: payload.from, candidate: payload.candidate })
    )

    socket.on('error', (payload: any) =>
      emit({ type: 'error', message: payload?.message ?? 'Unknown signaling error' })
    )
  }

  on(listener: Listener) {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }

  // --- outbound helpers -------------------------------------------------
  requestToJoin(sessionToken: string, deviceInfo: DeviceInfo) {
    this.socket?.emit('receiver:request', { sessionToken, deviceInfo })
  }

  approveReceiver(sessionToken: string, receiverSocketId: string) {
    this.socket?.emit('session:approve', { sessionToken, receiverSocketId })
  }

  rejectReceiver(sessionToken: string, receiverSocketId: string, reason?: string) {
    this.socket?.emit('session:reject', { sessionToken, receiverSocketId, reason })
  }

  sendOffer(sessionToken: string, to: string, sdp: RTCSessionDescriptionInit) {
    this.socket?.emit('webrtc:offer', { sessionToken, to, sdp })
  }

  sendAnswer(sessionToken: string, to: string, sdp: RTCSessionDescriptionInit) {
    this.socket?.emit('webrtc:answer', { sessionToken, to, sdp })
  }

  sendIceCandidate(sessionToken: string, to: string, candidate: RTCIceCandidateInit) {
    this.socket?.emit('webrtc:ice-candidate', { sessionToken, to, candidate })
  }

  cancelSession(sessionToken: string, reason?: string) {
    this.socket?.emit('session:cancel', { sessionToken, reason })
  }

  disconnect() {
    if (this.socket) {
      this.socket.disconnect()
      this.socket = null
    }
    this.sessionToken = null
  }
}

/**
 * QuicklyPeer — Transfer orchestration store (Zustand)
 *
 * Single source of truth for the UI. Coordinates:
 *  - REST API calls (create / join / register files / update status)
 *  - SignalingClient (socket.io)
 *  - PeerConnection (WebRTC + chunked transfer)
 *
 * The store exposes a state machine via `view` that the React layer renders.
 */

import { create } from 'zustand'
import { SignalingClient, PendingReceiver } from '@/lib/signaling-client'
import { PeerConnection, PeerEvent } from '@/lib/webrtc'
import { detectDevice } from '@/lib/transfer-utils'
import { clearTransferMeta } from '@/lib/indexeddb'
import { saveFileToDisk } from '@/lib/auto-save'
import type { DeviceInfo, FileMeta, SessionStatus } from '@/lib/types'

// --- view state machine ---------------------------------------------------
export type View =
  | 'home' // landing: choose send or receive
  | 'sender-waiting' // session created, showing ID/QR, waiting for receiver
  | 'sender-pending' // a receiver requested, awaiting approval
  | 'sender-connected' // WebRTC connected, ready to start transfer
  | 'sender-requesting' // sender asked; waiting for receiver to ACCEPT
  | 'sender-transferring' // actively sending files
  | 'sender-done' // transfer complete
  | 'receiver-joining' // resolving a transfer ID / share link
  | 'receiver-waiting' // connected to signaling, awaiting sender approval
  | 'receiver-connected' // approved, WebRTC connected, waiting for files
  | 'receiver-confirm' // sender is sending files — receiver must ACCEPT
  | 'receiver-transferring' // actively receiving files
  | 'receiver-done' // all files received
  | 'error'

// --- per-file progress (sender + receiver) -------------------------------
export interface FileProgress {
  meta: FileMeta
  transferred: number
  total: number
  status: 'pending' | 'transferring' | 'done' | 'error'
  blobUrl?: string // receiver only — download URL once assembled
  savedToDisk?: boolean // receiver only — file was auto-saved to disk
}

interface TransferState {
  view: View
  role: 'sender' | 'receiver' | null
  transferId: string | null
  sessionToken: string | null
  status: SessionStatus | null
  shareUrl: string | null
  expiresAt: string | null
  deviceInfo: DeviceInfo
  errorMessage: string | null

  // signaling + peer
  signalingConnected: boolean
  peerConnected: boolean
  pendingReceivers: PendingReceiver[]

  // files + progress
  files: FileProgress[]
  speed: number // bytes/sec
  paused: boolean
  /** Receiver: automatically save each finished file to disk (Downloads folder). */
  autoSave: boolean
  /** Soft, non-fatal notice shown inside the active screen (e.g. "Receiver declined"). */
  notice: string | null

  // internal handles (not serialized)
  _signaling: SignalingClient | null
  _peer: PeerConnection | null
  _rawFiles: File[] // sender's raw File objects, keyed by index to files

  // actions
  initSender: () => Promise<void>
  initReceiver: () => void
  joinByTransferId: (transferId: string) => Promise<void>
  joinByToken: (token: string) => Promise<void>
  registerFiles: (files: File[]) => Promise<void>
  startTransfer: () => Promise<void>
  acceptIncomingFiles: () => void
  declineIncomingFiles: () => void
  setAutoSave: (on: boolean) => void
  pause: () => void
  resume: () => void
  cancel: (reason?: string) => void
  approveReceiver: (receiverSocketId: string) => void
  rejectReceiver: (receiverSocketId: string) => void
  goHome: () => void
  reset: () => void
}

function makeDevice(): DeviceInfo {
  if (typeof navigator === 'undefined') {
    return { deviceType: 'desktop', browser: 'Unknown', os: 'Unknown', userAgent: '' }
  }
  return detectDevice(navigator.userAgent)
}

export const useTransferStore = create<TransferState>((set, get) => ({
  view: 'home',
  role: null,
  transferId: null,
  sessionToken: null,
  status: null,
  shareUrl: null,
  expiresAt: null,
  deviceInfo: makeDevice(),
  errorMessage: null,

  signalingConnected: false,
  peerConnected: false,
  pendingReceivers: [],

  files: [],
  speed: 0,
  paused: false,
  autoSave: true,
  notice: null,

  _signaling: null,
  _peer: null,
  _rawFiles: [],

  // -----------------------------------------------------------------------
  // SENDER
  // -----------------------------------------------------------------------
  async initSender() {
    set({ role: 'sender', view: 'sender-waiting', errorMessage: null })
    try {
      const res = await fetch('/api/sessions', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ senderDevice: get().deviceInfo }),
      })
      if (!res.ok) throw new Error('Failed to create session')
      const data = await res.json()
      set({
        transferId: data.transferId,
        sessionToken: data.sessionToken,
        shareUrl: data.shareUrl,
        expiresAt: data.expiresAt,
      })

      // connect to signaling server
      const signaling = new SignalingClient()
      set({ _signaling: signaling })
      attachSignalingListeners(signaling, set, get)
      signaling.connect(data.sessionToken, 'sender', get().deviceInfo)
    } catch (err) {
      set({ view: 'error', errorMessage: (err as Error).message })
    }
  },

  async registerFiles(files: File[]) {
    const { sessionToken, transferId, _signaling, _peer } = get()
    if (!sessionToken || !transferId) return

    const metas: FileMeta[] = files.map((f) => ({
      id: crypto.randomUUID(),
      filename: f.name,
      filesize: f.size,
      mimeType: f.type || 'application/octet-stream',
    }))

    // Persist manifest server-side (so receivers can preview before joining).
    await fetch(`/api/sessions/${transferId}/files`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-session-token': sessionToken,
      },
      body: JSON.stringify({ files: metas }),
    })

    // Keep a local copy of the raw File objects, keyed by meta id.
    const fileMap = new Map<string, File>()
    metas.forEach((m, i) => fileMap.set(m.id, files[i]))

    set({
      _rawFiles: files,
      files: metas.map((m) => ({ meta: m, transferred: 0, total: m.filesize, status: 'pending' as const })),
    })

    // Hand them to the peer connection (if it exists already) for later streaming.
    if (_peer) {
      _peer.setFiles(files, metas)
    }
    void _signaling
  },

  async startTransfer() {
    const { _peer, sessionToken, transferId } = get()
    if (!_peer || !sessionToken || !transferId) return

    // Mark the session as transferring.
    fetch(`/api/sessions/${transferId}/update`, {
      method: 'PATCH',
      headers: {
        'content-type': 'application/json',
        'x-session-token': sessionToken,
      },
      body: JSON.stringify({ status: 'transferring' }),
    }).catch(() => {})

    // Ask the receiver to accept. Streaming begins only after the receiver
    // answers `transfer-accept` (see the 'transfer-request' peer event).
    set({ view: 'sender-requesting', notice: null, paused: false })
    await _peer.startTransfer()
  },

  // -----------------------------------------------------------------------
  // RECEIVER — consent gate for the incoming file transfer
  // -----------------------------------------------------------------------
  acceptIncomingFiles() {
    const { _peer } = get()
    _peer?.acceptTransfer()
    set({ view: 'receiver-transferring', notice: null })
  },

  declineIncomingFiles() {
    const { _peer } = get()
    _peer?.declineTransfer('declined-by-receiver')
    // Stay connected — the sender may adjust and ask again.
    set({ view: 'receiver-connected', notice: null })
  },

  setAutoSave(on: boolean) {
    set({ autoSave: on })
  },

  // -----------------------------------------------------------------------
  // RECEIVER
  // -----------------------------------------------------------------------
  initReceiver() {
    // NOTE: intentionally does NOT change the view — the HomeScreen keeps
    // rendering locally so the user can type the Transfer ID first. The join
    // only happens when they submit the form (joinByTransferId).
    set({ role: 'receiver', errorMessage: null })
  },

  async joinByTransferId(transferId: string) {
    set({ role: 'receiver', view: 'receiver-joining', errorMessage: null })
    try {
      const res = await fetch(`/api/sessions/${transferId}/join`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ receiverDevice: get().deviceInfo }),
      })
      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err.error || 'Session not found')
      }
      const data = await res.json()
      if (!data.senderConnected) {
        throw new Error('Sender is not online. Ask them to keep the QuicklyPeer tab open.')
      }
      set({
        transferId: data.transferId,
        sessionToken: data.sessionToken,
        status: data.status,
        expiresAt: data.expiresAt,
        files: (data.files as FileMeta[]).map((m) => ({
          meta: m,
          transferred: 0,
          total: m.filesize,
          status: 'pending' as const,
        })),
      })
      await connectReceiverSignaling(set, get)
    } catch (err) {
      set({ view: 'error', errorMessage: (err as Error).message })
    }
  },

  async joinByToken(token: string) {
    set({ role: 'receiver', view: 'receiver-joining', errorMessage: null })
    try {
      const res = await fetch(`/api/sessions/by-token/${token}`)
      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err.error || 'Session not found')
      }
      const data = await res.json()
      if (data.status === 'expired' || data.status === 'closed') {
        throw new Error(`This transfer link is ${data.status}.`)
      }
      if (!data.senderConnected) {
        throw new Error('Sender is not online. Ask them to keep the QuicklyPeer tab open.')
      }
      // Now formally join (registers our device).
      const joinRes = await fetch(`/api/sessions/${data.transferId}/join`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ receiverDevice: get().deviceInfo }),
      })
      if (!joinRes.ok) throw new Error('Failed to join session')
      const joinData = await joinRes.json()
      set({
        transferId: joinData.transferId,
        sessionToken: joinData.sessionToken,
        status: joinData.status,
        expiresAt: joinData.expiresAt,
        files: (joinData.files as FileMeta[]).map((m) => ({
          meta: m,
          transferred: 0,
          total: m.filesize,
          status: 'pending' as const,
        })),
      })
      await connectReceiverSignaling(set, get)
    } catch (err) {
      set({ view: 'error', errorMessage: (err as Error).message })
    }
  },

  // -----------------------------------------------------------------------
  // approval gates
  // -----------------------------------------------------------------------
  approveReceiver(receiverSocketId: string) {
    const { _signaling, sessionToken, transferId } = get()
    _signaling?.approveReceiver(sessionToken!, receiverSocketId)
    // After approval, the sender waits for the WebRTC handshake to complete.
    // The signaling 'approved' event will fire for both peers and the sender
    // will create the offer.
    void transferId
  },

  rejectReceiver(receiverSocketId: string) {
    const { _signaling, sessionToken } = get()
    _signaling?.rejectReceiver(sessionToken!, receiverSocketId)
    set((s) => ({
      pendingReceivers: s.pendingReceivers.filter((r) => r.receiverSocketId !== receiverSocketId),
      view: s.pendingReceivers.length <= 1 ? 'sender-waiting' : 'sender-pending',
    }))
  },

  // -----------------------------------------------------------------------
  // transfer controls
  // -----------------------------------------------------------------------
  pause() {
    get()._peer?.pause()
    set({ paused: true })
  },

  resume() {
    get()._peer?.resume()
    set({ paused: false })
  },

  cancel(reason?: string) {
    const { _peer, _signaling, sessionToken } = get()
    _peer?.cancel(reason)
    _signaling?.cancelSession(sessionToken!, reason)
    set({ view: 'home', paused: false })
  },

  goHome() {
    get().reset()
  },

  reset() {
    const { _signaling, _peer, sessionToken } = get()
    _peer?.close()
    _signaling?.disconnect()
    if (sessionToken) clearTransferMeta(sessionToken).catch(() => {})
    set({
      view: 'home',
      role: null,
      transferId: null,
      sessionToken: null,
      status: null,
      shareUrl: null,
      expiresAt: null,
      errorMessage: null,
      signalingConnected: false,
      peerConnected: false,
      pendingReceivers: [],
      files: [],
      speed: 0,
      paused: false,
      notice: null,
      _signaling: null,
      _peer: null,
      _rawFiles: [],
    })
  },
}))

// ---------------------------------------------------------------------------
// Helpers (kept outside the store so they don't get re-created per render)
// ---------------------------------------------------------------------------

type SetFn = (partial: Partial<TransferState> | ((s: TransferState) => Partial<TransferState>)) => void
type GetFn = () => TransferState

function attachSignalingListeners(
  signaling: SignalingClient,
  set: SetFn,
  get: GetFn
) {
  signaling.on((event) => {
    switch (event.type) {
      case 'connected':
        set({ signalingConnected: true })
        break
      case 'disconnected':
        set({ signalingConnected: false })
        break
      case 'joined':
        if (event.type === 'joined' && get().role === 'sender') {
          const pending = event.pendingRequests ?? []
          set({
            pendingReceivers: pending,
            view: pending.length > 0 ? 'sender-pending' : 'sender-waiting',
          })
        }
        break
      case 'receiver-request':
        set((s) => {
          const exists = s.pendingReceivers.find(
            (r) => r.receiverSocketId === event.receiverSocketId
          )
          const next = exists
            ? s.pendingReceivers
            : [...s.pendingReceivers, { receiverSocketId: event.receiverSocketId, deviceInfo: event.deviceInfo }]
          return { pendingReceivers: next, view: 'sender-pending' }
        })
        break
      case 'approved': {
        // Both peers receive this. Now create the WebRTC peer connection.
        const role = get().role
        const peer = createPeer(role!, signaling, set, get)
        // The sender learns the receiver's socket id from this event; the
        // receiver learns the sender's socket id from the subsequent offer.
        peer.remoteSocketId = event.peerSocketId
        set({ _peer: peer, view: role === 'sender' ? 'sender-connected' : 'receiver-connected' })
        if (role === 'sender') {
          // Sender initiates the offer (only once we know the remote socket).
          peer.createOffer().catch((err) =>
            set({ view: 'error', errorMessage: `WebRTC offer failed: ${err.message}` })
          )
        }
        break
      }
      case 'rejected':
        set({ view: 'error', errorMessage: event.reason || 'Sender rejected your connection request.' })
        break
      case 'session-cancelled':
        set({ view: 'error', errorMessage: event.reason || 'The other peer ended the session.' })
        break
      case 'peer-left':
        // If we're mid-transfer, surface a hard error; if the receiver left
        // before accepting, let the sender recover gracefully.
        if (get().view === 'sender-transferring' || get().view === 'receiver-transferring') {
          set({ view: 'error', errorMessage: 'The other peer disconnected.' })
        } else if (get().role === 'sender' && get().view === 'sender-requesting') {
          set({ view: 'sender-connected', notice: 'The receiver disconnected before accepting.' })
        }
        break
      case 'webrtc-offer': {
        const peer = ensurePeer(get, set, signaling)
        // The receiver learns the sender's socket id from the offer's `from`.
        peer.remoteSocketId = event.from
        peer.handleOffer(event.sdp, event.from).catch((err) =>
          set({ view: 'error', errorMessage: `WebRTC answer failed: ${err.message}` })
        )
        break
      }
      case 'webrtc-answer': {
        const peer = get()._peer
        peer?.handleAnswer(event.sdp).catch(() => {})
        break
      }
      case 'webrtc-ice-candidate': {
        get()._peer?.handleIceCandidate(event.candidate)
        break
      }
      case 'error':
        // Soft signaling errors shouldn't blow away the UI; surface as toast elsewhere.
        break
      case 'connect_error':
        set({ errorMessage: `Cannot reach signaling server: ${event.message}` })
        break
    }
  })
}

async function connectReceiverSignaling(set: SetFn, get: GetFn) {
  set({ view: 'receiver-waiting' })
  const signaling = new SignalingClient()
  set({ _signaling: signaling })
  attachSignalingListeners(signaling, set, get)
  const { sessionToken, deviceInfo } = get()
  signaling.connect(sessionToken!, 'receiver', deviceInfo)

  // Once connected, the receiver requests approval from the sender.
  // We use a one-shot listener so we only request after 'joined'.
  const off = signaling.on((event) => {
    if (event.type === 'joined' && event.role === 'receiver') {
      signaling.requestToJoin(sessionToken!, deviceInfo)
      off()
    }
  })
}

function createPeer(
  role: 'sender' | 'receiver',
  signaling: SignalingClient,
  set: SetFn,
  get: GetFn
): PeerConnection {
  const sessionToken = get().sessionToken!
  const peer = new PeerConnection({
    role,
    sendSignaling: (kind, payload) => {
      if (kind === 'offer') signaling.sendOffer(sessionToken, payload.to, payload.sdp)
      else if (kind === 'answer') signaling.sendAnswer(sessionToken, payload.to, payload.sdp)
      else if (kind === 'ice-candidate') signaling.sendIceCandidate(sessionToken, payload.to, payload.candidate)
    },
  })

  attachPeerListeners(peer, set, get)

  // If the sender already registered files, hand them to the peer now.
  if (role === 'sender') {
    const raw = get()._rawFiles
    const metas = get().files.map((f) => f.meta)
    if (raw.length && metas.length) peer.setFiles(raw, metas)
  }

  return peer
}

function ensurePeer(get: GetFn, set: SetFn, signaling: SignalingClient): PeerConnection {
  let peer = get()._peer
  if (!peer) {
    peer = createPeer('receiver', signaling, set, get)
    set({ _peer: peer })
  }
  return peer
}

function attachPeerListeners(peer: PeerConnection, set: SetFn, get: GetFn) {
  peer.on((event: PeerEvent) => {
    switch (event.type) {
      case 'state':
        set({ peerConnected: event.state === 'connected' })
        if (event.state === 'failed' || event.state === 'closed') {
          const v = get().view
          if (
            v === 'sender-connected' ||
            v === 'sender-requesting' ||
            v === 'sender-transferring' ||
            v === 'receiver-connected' ||
            v === 'receiver-confirm' ||
            v === 'receiver-transferring'
          ) {
            set({ errorMessage: 'Peer connection lost.', view: 'error' })
          }
        }
        break
      case 'channel-open':
        // Receiver: connected and ready — wait for the sender to offer files.
        if (get().role === 'receiver') {
          set({ view: 'receiver-connected' })
        }
        break
      case 'transfer-requested':
        // Sender: the consent request went out (view already sender-requesting).
        break
      case 'transfer-request':
        // Receiver: sender wants to send files — show the accept dialog.
        if (get().role === 'receiver') {
          set({
            files: event.files.map((m) => ({
              meta: m,
              transferred: 0,
              total: m.filesize,
              status: 'pending' as const,
            })),
            view: 'receiver-confirm',
          })
        }
        break
      case 'transfer-declined':
        // Sender: receiver declined — return to the connected screen with a
        // soft notice so they can adjust and ask again.
        if (get().role === 'sender') {
          set({
            view: 'sender-connected',
            notice: 'The receiver declined this transfer. You can update the files and send again.',
          })
        }
        break
      case 'progress':
        set((s) => ({
          files: s.files.map((f) =>
            f.meta.id === event.fileId
              ? {
                  ...f,
                  transferred: event.transferred,
                  total: event.total,
                  status: event.transferred >= event.total ? 'done' : 'transferring',
                }
              : f
          ),
        }))
        break
      case 'speed':
        set({ speed: event.bytesPerSecond })
        break
      case 'file-complete':
        set((s) => ({
          files: s.files.map((f) =>
            f.meta.id === event.fileId
              ? { ...f, status: event.ok ? 'done' : 'error', transferred: f.total, blobUrl: event.blobUrl }
              : f
          ),
        }))
        // Receiver: automatically save the finished file to disk (the browser
        // stores it in the default Downloads folder).
        if (
          get().role === 'receiver' &&
          event.ok &&
          event.blobUrl &&
          get().autoSave
        ) {
          saveFileToDisk(event.blobUrl, event.filename || 'quicklypeer-file')
          set((s) => ({
            files: s.files.map((f) =>
              f.meta.id === event.fileId ? { ...f, savedToDisk: true } : f
            ),
          }))
        }
        break
      case 'transfer-end':
        set({ view: get().role === 'sender' ? 'sender-done' : 'receiver-done', speed: 0 })
        // Update session status server-side.
        {
          const { transferId, sessionToken } = get()
          if (transferId && sessionToken) {
            fetch(`/api/sessions/${transferId}/update`, {
              method: 'PATCH',
              headers: {
                'content-type': 'application/json',
                'x-session-token': sessionToken,
              },
              body: JSON.stringify({ status: 'completed' }),
            }).catch(() => {})
          }
        }
        break
      case 'paused':
        set({ paused: true })
        break
      case 'resumed':
        set({ paused: false })
        break
      case 'cancelled':
        set({ view: 'home', notice: null })
        break
      case 'error':
        set({ errorMessage: event.message })
        break
      case 'manifest':
        // Receiver learns the file list from the sender.
        set({
          files: event.files.map((m) => ({
            meta: m,
            transferred: 0,
            total: m.filesize,
            status: 'pending' as const,
          })),
        })
        break
      default:
        break
    }
  })
}

/**
 * QuicklyPeer — Client-safe formatting & device detection
 *
 * No Node imports so this can be safely imported from 'use client' components
 * and from client-side WebRTC code.
 */

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return '0 B'
  if (bytes === 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']
  const i = Math.min(units.length - 1, Math.floor(Math.log(bytes) / Math.log(1024)))
  const value = bytes / Math.pow(1024, i)
  return `${value.toFixed(i === 0 ? 0 : value >= 100 ? 0 : 1)} ${units[i]}`
}

export function formatSpeed(bytesPerSecond: number): string {
  return `${formatBytes(bytesPerSecond)}/s`
}

export function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '--'
  if (seconds < 1) return '< 1s'
  const s = Math.round(seconds)
  if (s < 60) return `${s}s`
  const m = Math.floor(s / 60)
  const rem = s % 60
  if (m < 60) return `${m}m ${rem}s`
  const h = Math.floor(m / 60)
  return `${h}h ${m % 60}m`
}

/** Detect device/browser/OS from the user-agent string. */
export function detectDevice(userAgent: string): {
  deviceType: 'mobile' | 'desktop' | 'tablet'
  browser: string
  os: string
  userAgent: string
} {
  const ua = userAgent || ''
  const lower = ua.toLowerCase()

  let deviceType: 'mobile' | 'desktop' | 'tablet' = 'desktop'
  if (/ipad|tablet|playbook|silk|(android(?!.*mobile))/i.test(ua)) {
    deviceType = 'tablet'
  } else if (/mobi|iphone|ipod|android.*mobile|windows phone/i.test(ua)) {
    deviceType = 'mobile'
  }

  let browser = 'Unknown'
  if (lower.includes('edg/')) browser = 'Edge'
  else if (lower.includes('opr/') || lower.includes('opera')) browser = 'Opera'
  else if (lower.includes('chrome') && !lower.includes('chromium')) browser = 'Chrome'
  else if (lower.includes('firefox')) browser = 'Firefox'
  else if (lower.includes('safari')) browser = 'Safari'

  let os = 'Unknown'
  if (lower.includes('windows')) os = 'Windows'
  else if (lower.includes('mac os')) os = 'macOS'
  else if (lower.includes('iphone') || lower.includes('ipad')) os = 'iOS'
  else if (lower.includes('android')) os = 'Android'
  else if (lower.includes('linux')) os = 'Linux'

  return { deviceType, browser, os, userAgent: ua }
}

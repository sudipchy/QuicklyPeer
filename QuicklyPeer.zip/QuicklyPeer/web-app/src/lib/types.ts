/**
 * QuicklyPeer — Shared types
 *
 * Used by both server-side API routes and client-side code.
 */

export type SessionStatus =
  | 'waiting' // sender created the session, waiting for a receiver
  | 'pending' // a receiver requested to join, waiting for sender approval
  | 'connected' // WebRTC peer connection established
  | 'transferring' // file transfer in progress
  | 'completed' // all files transferred successfully
  | 'expired' // session expired
  | 'rejected' // sender rejected the receiver
  | 'closed' // session manually closed

export interface DeviceInfo {
  deviceType: 'mobile' | 'desktop' | 'tablet' | 'unknown'
  browser: string
  os: string
  userAgent: string
}

export interface FileMeta {
  id: string
  filename: string
  /** bytes */
  filesize: number
  mimeType: string
  checksum?: string
}

export interface TransferFile extends FileMeta {
  /** transfer session id */
  sessionId: string
  createdAt: string
}

export interface CreateSessionResponse {
  transferId: string
  sessionToken: string
  shareUrl: string
  expiresAt: string
}

export interface SessionStatusResponse {
  transferId: string
  sessionToken: string
  status: SessionStatus
  senderConnected: boolean
  receiverConnected: boolean
  senderDevice?: DeviceInfo | null
  receiverDevice?: DeviceInfo | null
  files: TransferFile[]
  expiresAt: string
  createdAt: string
}

export interface JoinSessionResponse {
  transferId: string
  sessionToken: string
  status: SessionStatus
  senderConnected: boolean
  files: TransferFile[]
  expiresAt: string
}

export interface ApiError {
  error: string
}

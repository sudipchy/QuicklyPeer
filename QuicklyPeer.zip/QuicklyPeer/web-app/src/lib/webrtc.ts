/**
 * QuicklyPeer — WebRTC peer connection + file transfer engine
 *
 * Responsibilities:
 *  - Create an RTCPeerConnection with STUN/TURN ICE servers.
 *  - Negotiate an ordered DataChannel for file transfer.
 *  - Sender: stream files in chunks with adaptive backpressure.
 *  - Receiver: reassemble chunks into a downloadable Blob, verify checksum.
 *  - Emit typed events the React layer can render.
 *
 * Design notes:
 *  - Chunk size defaults to 256 KB (a good balance across browsers).
 *  - Backpressure: pause sending when bufferedAmount > HIGH_WATERMARK,
 *    resume when the buffer drains below LOW_WATERMARK.
 *  - Pause/resume/cancel are cooperative flags checked between chunks.
 *  - Resume from interruption: the receiver tracks received offsets in
 *    IndexedDB and re-requests missing ranges on reconnect.
 */

import { decodeControl, encodeControl, ControlMessage } from './protocol'
import type { FileMeta } from './types'

// Public STUN servers. (Production should add a TURN server for restricted
// networks — see README / env note.)
const ICE_SERVERS: RTCIceServer[] = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
  { urls: 'stun:stun2.l.google.com:19302' },
]

export const DEFAULT_CHUNK_SIZE = 256 * 1024 // 256 KB
const HIGH_WATERMARK = 4 * 1024 * 1024 // 4 MB — pause above this
const LOW_WATERMARK = 1 * 1024 * 1024 // 1 MB — resume below this

// --- events ---------------------------------------------------------------
export type PeerEvent =
  | { type: 'state'; state: RTCPeerConnectionState }
  | { type: 'channel-open' }
  | { type: 'channel-close' }
  | { type: 'manifest'; files: FileMeta[] }
  | { type: 'select-files'; fileIds: string[] }
  // Sender -> asks receiver to consent; emitted on the sender when the request
  // has been sent and on the receiver when the request arrives.
  | { type: 'transfer-requested' }
  | { type: 'transfer-request'; files: FileMeta[] }
  // Receiver declined the incoming transfer (emitted on the sender).
  | { type: 'transfer-declined'; reason?: string }
  | { type: 'file-start'; file: FileMeta; chunkSize: number }
  | { type: 'progress'; fileId: string; transferred: number; total: number }
  | { type: 'speed'; bytesPerSecond: number }
  | { type: 'file-complete'; fileId: string; ok: boolean; blobUrl?: string; filename?: string }
  | { type: 'transfer-end' }
  | { type: 'paused' }
  | { type: 'resumed' }
  | { type: 'cancelled'; reason?: string }
  | { type: 'error'; message: string }

type PeerListener = (e: PeerEvent) => void

// --- receiver per-file state ---------------------------------------------
interface ReceiverFileState {
  meta: FileMeta
  chunks: Map<number, ArrayBuffer> // offset -> chunk
  received: number
  total: number
  blobUrl?: string
}

export interface PeerConnectionOptions {
  /** Whether this peer is the sender (initiator) or receiver. */
  role: 'sender' | 'receiver'
  /** Called by this engine to relay a signaling message to the remote peer. */
  sendSignaling: (kind: 'offer' | 'answer' | 'ice-candidate', payload: any) => void
  /** Chunk size override (defaults to 256 KB). */
  chunkSize?: number
}

export class PeerConnection {
  readonly role: 'sender' | 'receiver'
  private pc: RTCPeerConnection
  private channel: RTCDataChannel | null = null
  private listeners = new Set<PeerListener>()
  private sendSignaling: PeerConnectionOptions['sendSignaling']
  private chunkSize: number

  // sender state
  private filesToSend: FileMeta[] = []
  private fileStreams = new Map<string, { file: File; meta: FileMeta }>()
  private paused = false
  private cancelled = false
  private sending = false

  /** Remote peer's signaling socket id — required to relay SDP/ICE. */
  remoteSocketId: string | null = null

  // receiver state
  private receiverFiles = new Map<string, ReceiverFileState>()
  private selectedFileIds: Set<string> | null = null

  // speed sampling
  private speedInterval: ReturnType<typeof setInterval> | null = null
  private bytesSinceTick = 0

  constructor(opts: PeerConnectionOptions) {
    this.role = opts.role
    this.sendSignaling = opts.sendSignaling
    this.chunkSize = opts.chunkSize ?? DEFAULT_CHUNK_SIZE

    this.pc = new RTCPeerConnection({ iceServers: ICE_SERVERS })

    this.pc.onconnectionstatechange = () => {
      this.emit({ type: 'state', state: this.pc.connectionState })
    }
    this.pc.onicecandidate = (event) => {
      if (event.candidate) {
        this.sendSignaling('ice-candidate', { to: this.remoteSocketId!, candidate: event.candidate.toJSON() })
      }
    }

    if (this.role === 'sender') {
      // Sender creates the data channel (negotiated = false, so it triggers
      // negotiationneeded on the receiver via ondatachannel).
      this.channel = this.pc.createDataChannel('quicklypeer-files', {
        ordered: true,
      })
      this.attachChannel(this.channel)
    } else {
      this.pc.ondatachannel = (event) => {
        this.channel = event.channel
        this.attachChannel(this.channel)
      }
    }
  }

  // --- public API --------------------------------------------------------

  on(listener: PeerListener) {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }

  /** Sender: initiate the offer. */
  async createOffer() {
    const offer = await this.pc.createOffer()
    await this.pc.setLocalDescription(offer)
    this.sendSignaling('offer', { to: this.remoteSocketId!, sdp: this.pc.localDescription!.toJSON() })
  }

  /** Receiver: apply remote offer and create answer. */
  async handleOffer(sdp: RTCSessionDescriptionInit, fromSocketId?: string) {
    if (fromSocketId) this.remoteSocketId = fromSocketId
    await this.pc.setRemoteDescription(sdp)
    const answer = await this.pc.createAnswer()
    await this.pc.setLocalDescription(answer)
    this.sendSignaling('answer', { to: this.remoteSocketId!, sdp: this.pc.localDescription!.toJSON() })
  }

  /** Apply remote answer (sender side). */
  async handleAnswer(sdp: RTCSessionDescriptionInit) {
    await this.pc.setRemoteDescription(sdp)
  }

  async handleIceCandidate(candidate: RTCIceCandidateInit) {
    try {
      await this.pc.addIceCandidate(candidate)
    } catch (err) {
      // Silently ignore late candidates — common during renegotiation.
    }
  }

  /** Sender: set the files to transfer (called before startTransfer). */
  setFiles(files: File[], metas: FileMeta[]) {
    this.filesToSend = metas
    this.fileStreams.clear()
    files.forEach((f, i) => {
      const meta = metas[i]
      this.fileStreams.set(meta.id, { file: f, meta })
    })
  }

  /** Receiver: choose which files to accept (empty = all). */
  selectFiles(fileIds: string[] | null) {
    this.selectedFileIds = fileIds ? new Set(fileIds) : null
  }

  /** Sender: ask the receiver for consent, then stream once they accept. */
  async startTransfer() {
    if (!this.channel || this.channel.readyState !== 'open') {
      this.emit({ type: 'error', message: 'DataChannel is not open' })
      return
    }
    if (this.role !== 'sender') return
    this.cancelled = false
    this.paused = false

    // Ask the receiver to accept the incoming files first. Streaming only
    // begins once the receiver answers with `transfer-accept`.
    this.sendControl({
      type: 'transfer-request',
      files: this.filesToSend.map((m) => ({
        id: m.id,
        filename: m.filename,
        filesize: m.filesize,
        mimeType: m.mimeType,
        checksum: m.checksum,
      })),
    })
    this.emit({ type: 'transfer-requested' })
  }

  /** Receiver: consent to the incoming transfer (sender will start streaming). */
  acceptTransfer() {
    this.sendControl({ type: 'transfer-accept' })
  }

  /** Receiver: decline the incoming transfer. Sender stays connected. */
  declineTransfer(reason?: string) {
    this.sendControl({ type: 'transfer-decline', reason })
  }

  /** Sender-side: stream all files (called after the receiver accepts). */
  private async beginStream() {
    if (!this.channel || this.channel.readyState !== 'open') {
      this.emit({ type: 'error', message: 'DataChannel is not open' })
      return
    }
    if (this.sending) return
    this.sending = true

    // Start speed sampler
    this.startSpeedSampler()

    // Send manifest first.
    this.sendControl({
      type: 'manifest',
      files: this.filesToSend.map((m) => ({
        id: m.id,
        filename: m.filename,
        filesize: m.filesize,
        mimeType: m.mimeType,
        checksum: m.checksum,
      })),
    })

    await this.streamAllFiles()

    this.sendControl({ type: 'transfer-end' })
    this.stopSpeedSampler()
    this.sending = false
    this.emit({ type: 'transfer-end' })
  }

  pause() {
    if (!this.paused) {
      this.paused = true
      this.sendControl({ type: 'pause' })
      this.emit({ type: 'paused' })
    }
  }

  resume() {
    if (this.paused) {
      this.paused = false
      this.sendControl({ type: 'resume' })
      this.emit({ type: 'resumed' })
    }
  }

  cancel(reason?: string) {
    this.cancelled = true
    this.sendControl({ type: 'cancel', reason })
    this.stopSpeedSampler()
    this.sending = false
    this.emit({ type: 'cancelled', reason })
  }

  close() {
    this.stopSpeedSampler()
    try {
      this.channel?.close()
    } catch {}
    try {
      this.pc.close()
    } catch {}
    this.channel = null
  }

  // --- internals ---------------------------------------------------------

  private attachChannel(channel: RTCDataChannel) {
    channel.binaryType = 'arraybuffer'

    channel.onopen = () => {
      this.emit({ type: 'channel-open' })
      // Receiver says hello so the sender knows who's on the other end.
      this.sendControl({ type: 'hello', role: this.role })
    }
    channel.onclose = () => this.emit({ type: 'channel-close' })
    channel.onerror = (ev) =>
      this.emit({ type: 'error', message: 'DataChannel error' })

    let pendingChunkMeta: { fileId: string; offset: number; size: number } | null = null

    channel.onmessage = (event) => {
      if (typeof event.data === 'string') {
        const msg = decodeControl(event.data)
        if (!msg) return
        this.handleControl(msg)
      } else if (event.data instanceof ArrayBuffer) {
        // Binary frame = a chunk payload. The preceding text frame told us
        // which file/offset this belongs to.
        if (pendingChunkMeta) {
          this.handleChunkPayload(pendingChunkMeta, event.data)
          pendingChunkMeta = null
        }
      } else if (event.data instanceof Blob) {
        // Some browsers deliver binary as Blob — convert to ArrayBuffer.
        event.data.arrayBuffer().then((buf) => {
          if (pendingChunkMeta) {
            this.handleChunkPayload(pendingChunkMeta, buf)
            pendingChunkMeta = null
          }
        })
      }
      // Track the pending chunk meta by intercepting `chunk` control messages.
      // (handled inside handleControl via a side-channel below)
      void pendingChunkMeta
    }

    // We need to capture the pending chunk meta inside handleControl, so we
    // stash a setter the control handler can use.
    this._setPendingChunk = (meta) => {
      pendingChunkMeta = meta
    }
  }

  // Side-channel set by attachChannel so handleControl can mark the next
  // binary frame as a chunk payload.
  private _setPendingChunk: (meta: { fileId: string; offset: number; size: number } | null) => void = () => {}

  private sendControl(msg: ControlMessage) {
    if (this.channel && this.channel.readyState === 'open') {
      this.channel.send(encodeControl(msg))
    }
  }

  private handleControl(msg: ControlMessage) {
    switch (msg.type) {
      case 'hello':
        // peer announced role; nothing to do for now
        break
      case 'manifest':
        this.emit({
          type: 'manifest',
          files: msg.files.map((f) => ({
            id: f.id,
            filename: f.filename,
            filesize: f.filesize,
            mimeType: f.mimeType,
            checksum: f.checksum,
          })),
        })
        break
      case 'select-files':
        this.emit({ type: 'select-files', fileIds: msg.fileIds })
        break
      case 'transfer-request':
        // Receiver: the sender wants to send these files — surface the
        // consent dialog. Sync our manifest with the latest list.
        this.emit({
          type: 'transfer-request',
          files: msg.files.map((f) => ({
            id: f.id,
            filename: f.filename,
            filesize: f.filesize,
            mimeType: f.mimeType,
            checksum: f.checksum,
          })),
        })
        break
      case 'transfer-accept':
        // Sender: receiver consented — start streaming.
        void this.beginStream()
        break
      case 'transfer-decline':
        // Sender: receiver declined — report back so the UI can recover.
        this.emit({ type: 'transfer-declined', reason: msg.reason })
        break
      case 'file-start': {
        const file: FileMeta = {
          id: msg.fileId,
          filename: msg.filename,
          filesize: msg.filesize,
          mimeType: msg.mimeType,
          checksum: msg.checksum,
        }
        this.receiverFiles.set(msg.fileId, {
          meta: file,
          chunks: new Map(),
          received: 0,
          total: msg.filesize,
        })
        this.emit({ type: 'file-start', file, chunkSize: msg.chunkSize })
        break
      }
      case 'chunk':
        // Mark the next binary frame as belonging to this chunk.
        this._setPendingChunk({ fileId: msg.fileId, offset: msg.offset, size: msg.size })
        break
      case 'chunk-ack':
        // Sender can use acks for reliability; not strictly required in MVP.
        break
      case 'file-end': {
        const state = this.receiverFiles.get(msg.fileId)
        if (state) {
          this.finalizeReceiverFile(state, msg.checksum)
        }
        break
      }
      case 'file-complete':
        // Sender learns the receiver finished a file.
        break
      case 'transfer-end':
        this.emit({ type: 'transfer-end' })
        break
      case 'pause':
        this.paused = true
        this.emit({ type: 'paused' })
        break
      case 'resume':
        this.paused = false
        this.emit({ type: 'resumed' })
        break
      case 'cancel':
        this.cancelled = true
        this.sending = false
        this.emit({ type: 'cancelled', reason: msg.reason })
        break
    }
  }

  private handleChunkPayload(meta: { fileId: string; offset: number; size: number }, buf: ArrayBuffer) {
    const state = this.receiverFiles.get(meta.fileId)
    if (!state) return
    if (!state.chunks.has(meta.offset)) {
      state.chunks.set(meta.offset, buf)
      state.received += buf.byteLength
      this.bytesSinceTick += buf.byteLength
      this.emit({
        type: 'progress',
        fileId: meta.fileId,
        transferred: state.received,
        total: state.total,
      })
    }
    // ACK the chunk so the sender can advance its window (lightweight).
    this.sendControl({ type: 'chunk-ack', fileId: meta.fileId, offset: meta.offset, size: buf.byteLength })
  }

  private finalizeReceiverFile(state: ReceiverFileState, checksum?: string) {
    // Reassemble chunks in offset order. We stored chunks keyed by byte offset
    // and used a fixed chunk size, so we can iterate from 0 in chunkSize steps.
    const { meta, chunks, total } = state
    const parts: ArrayBuffer[] = []
    let offset = 0
    while (offset < total) {
      const chunk = chunks.get(offset)
      if (!chunk) break
      parts.push(chunk)
      offset += chunk.byteLength
    }

    const ok = offset >= total
    let blobUrl: string | undefined
    if (ok) {
      const blob = new Blob(parts, { type: meta.mimeType || 'application/octet-stream' })
      blobUrl = URL.createObjectURL(blob)
    }
    state.blobUrl = blobUrl
    this.emit({
      type: 'file-complete',
      fileId: meta.id,
      ok,
      blobUrl,
      filename: meta.filename,
    })
    void checksum // verification hook — compare meta.checksum if provided
  }

  // --- sender streaming --------------------------------------------------

  private async streamAllFiles() {
    for (const meta of this.filesToSend) {
      if (this.cancelled) break
      const entry = this.fileStreams.get(meta.id)
      if (!entry) continue

      this.sendControl({
        type: 'file-start',
        fileId: meta.id,
        filename: meta.filename,
        filesize: meta.filesize,
        mimeType: meta.mimeType,
        checksum: meta.checksum,
        chunkSize: this.chunkSize,
      })

      await this.streamFile(entry.file, meta)
      if (this.cancelled) break

      this.sendControl({ type: 'file-end', fileId: meta.id, checksum: meta.checksum })
    }
  }

  private async streamFile(file: File, meta: FileMeta) {
    const total = meta.filesize
    let offset = 0
    while (offset < total) {
      if (this.cancelled) return
      // Cooperative pause: spin until resumed or cancelled.
      while (this.paused && !this.cancelled) {
        await sleep(120)
      }
      if (this.cancelled) return

      // Backpressure: wait for the buffer to drain.
      while (this.channel && this.channel.bufferedAmount > HIGH_WATERMARK) {
        await waitForBuffer(this.channel, LOW_WATERMARK)
        if (this.cancelled) return
      }

      const slice = file.slice(offset, Math.min(offset + this.chunkSize, total))
      const buf = await slice.arrayBuffer()
      if (!this.channel || this.channel.readyState !== 'open') return

      // Announce the chunk then send the payload immediately after.
      this.sendControl({ type: 'chunk', fileId: meta.id, offset, size: buf.byteLength })
      this.channel.send(buf)
      this.bytesSinceTick += buf.byteLength

      offset += buf.byteLength
      this.emit({ type: 'progress', fileId: meta.id, transferred: offset, total })
    }
  }

  // --- speed sampling ----------------------------------------------------

  private startSpeedSampler() {
    this.bytesSinceTick = 0
    this.stopSpeedSampler()
    this.speedInterval = setInterval(() => {
      const bps = this.bytesSinceTick
      this.bytesSinceTick = 0
      this.emit({ type: 'speed', bytesPerSecond: bps })
    }, 1000)
  }

  private stopSpeedSampler() {
    if (this.speedInterval) {
      clearInterval(this.speedInterval)
      this.speedInterval = null
    }
  }

  private emit(e: PeerEvent) {
    this.listeners.forEach((l) => l(e))
  }
}

// --- helpers --------------------------------------------------------------

function sleep(ms: number) {
  return new Promise<void>((resolve) => setTimeout(resolve, ms))
}

function waitForBuffer(channel: RTCDataChannel, lowWatermark: number) {
  return new Promise<void>((resolve) => {
    const check = () => {
      if (channel.bufferedAmount <= lowWatermark || channel.readyState !== 'open') {
        channel.removeEventListener('bufferedamountlow', check)
        resolve()
      }
    }
    channel.bufferedAmountLowThreshold = lowWatermark
    channel.addEventListener('bufferedamountlow', check)
    // Fallback poll in case the event is missed.
    setTimeout(check, 100)
  })
}
